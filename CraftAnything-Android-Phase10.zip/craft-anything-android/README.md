# Craft Anything Android — starter app

This is an Android-native starter shell for porting `storytold/craft-anything`.

## What is included
- Kotlin + Jetpack Compose mobile UI
- Android document picker for APK/ZIP/other files
- Rust JNI bridge boundary (`native-lib`)
- Android build configuration and a minimal Rust `cdylib`
- Clear integration notes for connecting the upstream Rust engine

## Important status
This is a **starter scaffold**, not a completed port of the upstream application and not a tested APK.
The upstream project is a large Rust workspace. Its engine is not currently exposed as an Android JNI
library, and its desktop UI crate depends on desktop windowing/dialog behavior. A real port needs
platform abstraction work before the engine can be linked safely into an Android app.

## Build prerequisites
- Android Studio (current stable)
- Android SDK / Build Tools
- Android NDK and CMake (for the Rust native library packaging)
- Rust toolchain with `aarch64-linux-android`, `armv7-linux-androideabi`,
  `x86_64-linux-android` targets
- `cargo-ndk`

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync and install the Android SDK components it requests.
3. Install Rust targets and `cargo-ndk`.
4. Run `./native/build-android.sh` to build the JNI smoke-test library for arm64-v8a and x86_64.
5. Build and run the `app` configuration.

The Rust library in this scaffold only proves the JNI boundary. It does not yet call Craft Anything's
engine. The next integration step is to create a headless Android-compatible facade over
`craft-anything-engine`, `craft-anything-ai`, and `craft-anything-platform`, then wire its typed
operations to the Kotlin UI.

## Product decisions
- UI: native Android / Jetpack Compose
- Rust: existing engine, exposed through a narrow JNI API
- Minimum SDK: 26 (Android 8.0)
- Target SDK: 35
- Initial ABI: arm64-v8a; add x86_64 for emulator testing
- Android app id: `ai.storyteller.craftanything`

See [the upstream compatibility audit](docs/COMPATIBILITY_AUDIT.md) for the confirmed blockers and port boundary.

## Phase 2: engine bridge

The app now calls a Rust JNI bridge for status and a tool-catalog JSON payload.
The real upstream engine catalog is gated behind the optional `upstream-engine` Cargo
feature because the current platform crate is not yet verified on Android. See
`docs/PHASE2_ENGINE_BRIDGE.md`.


## Phase 3
See `docs/PHASE3_FILE_ANALYSIS.md`. The app now has a SAF picker and bounded JNI/Rust signature-and-hash inspection for APK/DEX/ELF/PE/ZIP candidates.


## Phase 4
See `docs/PHASE4_UPSTREAM_FORMAT_PARSERS.md`. Optional JNI integration now calls the upstream pure-Rust ZIP and DEX parsers.


## Phase 5

See [Phase 5 implementation notes](docs/PHASE5_MANIFEST_RESOURCES_UI.md) for binary AndroidManifest.xml decoding, `resources.arsc` parsing, and the Compose results summary.

## Phase 6

See [Phase 6 implementation notes](docs/PHASE6_ENGINE_TOOLS_AND_APK.md) for bounded Dalvik method disassembly, the read-only Android engine-tool JNI facade, and the APK build script. The original engine feature is opt-in pending Android platform-crate validation.


## Phase 7: AI providers and tool-calling chat

See `docs/PHASE7_AI_PROVIDERS_AND_AGENT_LOOP.md`.

- Native Android provider settings for OpenAI, Anthropic, Gemini, OpenRouter, Qwen/DashScope, Ollama, and custom OpenAI-compatible endpoints.
- API keys are encrypted with AES-GCM using an Android Keystore key; only ciphertext is stored in app preferences.
- A bounded ReAct-style chat loop supports OpenAI-compatible function calling and Anthropic tool-use messages.
- The model is offered only six read-only Android analysis tools. The target APK is never executed by the AI layer.
- Ollama and custom local endpoints may use HTTP only for localhost/private-network addresses; cloud endpoints require HTTPS.

**Porting boundary:** this is a focused Android implementation of the API-provider and tool-calling path, not a full port of upstream `crates/ai`. The upstream ACP/CLI adapters, crews, rebuild/build tools, transcript journal, model discovery, pricing and context-window management are not yet ported. The native tool-call facade still requires a successful Android build with the optional `upstream-engine` feature; until then the chat UI/API can run, but model-requested Rust tools return an explicit unavailable error. No live API call or Android build has been verified in this environment.


### Phase 8 status

Upstream AI parity audit: `docs/PHASE8_UPSTREAM_AI_PARITY.md`. The Android app still uses the focused Phase 7 Kotlin agent loop; the upstream Rust `craft-anything-ai` loop is not yet integrated. No APK build is claimed.


## Phase 9 — mobile redesign and optimization

See `docs/PHASE9_MOBILE_REDESIGN.md`. The app now has four mobile destinations (Analyze, Tools, AI, Settings), bounded compact result rendering, reduced duplicate allocation for known-size documents, avoids reading APK bytes for text-only AI requests when native tools are unavailable, and enables release shrinking with JNI keep rules.

## Phase 10 — visual redesign

The Android Compose UI now uses a Studio-inspired dark graphite theme, restrained blue accent, consistent card surfaces, improved typography hierarchy, and a more deliberate bottom navigation treatment. See `docs/PHASE10_VISUAL_REDESIGN.md`. This is a mobile adaptation of upstream design-system principles, not a pixel-perfect copy of the desktop egui UI.
