# Phase 7 — AI providers and tool-calling chat

## Why this follows upstream

The upstream AI crate separates provider adapters from its agent loop. It has native HTTP adapters for Anthropic, OpenAI, OpenRouter, Gemini (through an OpenAI-compatible endpoint), and OpenAI-compatible local servers such as Ollama/LM Studio/vLLM. It separately supports agent CLIs over subprocess/ACP. This Android phase implements the API path first; Android does not assume desktop CLI binaries exist.

## Provider presets

| Preset | Wire protocol | Default endpoint |
|---|---|---|
| OpenAI GPT | OpenAI Chat Completions | `https://api.openai.com/v1` |
| Anthropic Claude | Anthropic Messages | `https://api.anthropic.com` |
| Gemini | OpenAI-compatible Gemini endpoint | `https://generativelanguage.googleapis.com/v1beta/openai` |
| OpenRouter | OpenAI-compatible | `https://openrouter.ai/api/v1` |
| Qwen / DashScope | OpenAI-compatible | `https://dashscope-intl.aliyuncs.com/compatible-mode/v1` |
| Ollama | OpenAI-compatible | `http://10.0.2.2:11434/v1` (Android emulator host bridge) |
| Custom | OpenAI-compatible | User supplied |

Qwen is a preset for convenience, not a dedicated upstream `BackendKind`. Qwen models can also be selected through OpenRouter or any compatible endpoint. Ollama is likewise an OpenAI-compatible backend, not a separate upstream wire protocol.

## Implemented

- Provider/model/base URL selection and API key entry.
- AES-GCM encryption with a key held in Android Keystore. API keys are not logged.
- OpenAI-compatible and Anthropic request formats.
- Model discovery through `/models` for OpenAI-compatible services and `/v1/models` for Anthropic, with manual model ID entry retained when discovery is unavailable.
- Tool calling for both protocols.
- The UI only advertises Rust analysis tools when the native engine catalog reports that the upstream engine is connected; otherwise the model is explicitly told it has no live tools.
- Six explicit read-only Android tools: package info, class search, class detail, class references, resources and components.
- Maximum six tool-call rounds per user request; user prompt and tool outputs are bounded.
- HTTP is accepted only for local/private addresses for Ollama/custom. Cloud API endpoints require HTTPS.
- AI prompts are evidence-led and instruct the model to distinguish facts, hypotheses and unknowns.

## Not yet ported

- Upstream full `ApiConversation` implementation, provider fallback chain, usage/cost meter, transcript persistence, streaming deltas and context-window fitting. Basic provider model-list discovery is implemented, but not the upstream model metadata/capability catalogue.
- ACP and external CLI agents (Claude Code, Codex, Gemini CLI, Qwen Code, OpenCode, etc.). Android app subprocess compatibility and their login lifecycles need a separate design.
- Builder/rebuild tools, file writes, command execution and approval inbox. These must not be silently enabled by a chat model.
- Live provider integration tests. No live API key was used in this environment.

## Native engine dependency

`AiChatClient` calls the JNI `nativeRunAndroidTool` facade when a model requests a tool. The existing Rust facade intentionally returns a clear unavailable error unless built with `upstream-engine`. That optional feature has not been validated for Android because the upstream platform/keychain/PTY dependencies need Android-specific adaptation. Do not describe tool execution as available until that build succeeds.

## Build and verification status

The app source was updated, but this environment has no Gradle/Rust/Android SDK toolchain. Therefore there is no claim of a successful compile, live API call, device test or APK. Build locally using the existing `build-apk.sh` after Android SDK, NDK, Rust Android targets and `cargo-ndk` are installed. For the AI-only UI/API path, the app's native library must at least provide the JNI symbols from the project; model-requested tools remain unavailable without the engine feature.
