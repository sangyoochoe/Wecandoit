# Phase 6 — Android engine tools, Dalvik disassembly, and APK build path

## Implemented

### 1. Dalvik method disassembly
- Added JNI `nativeDisassembleAndroidMethod`.
- Accepts a selected bare DEX or APK, class name, and method name.
- Uses upstream `craft-anything-formats` ZIP/DEX parsers and `dex_ops::decode`.
- Produces instruction offsets, opcodes, widths, and resolved smali-like text using the upstream formatter.
- Includes register counts and try/catch metadata.
- Hard limits: 64 MiB selected input, 20,000 ZIP entries, 64 DEX members, 32 MiB per DEX member, 200,000 decode units, 5,000 rendered instructions.
- Abstract/native methods are reported as having no code item. Overloaded methods currently select the first declaration-order match.

### 2. Original engine tool dispatch facade
- Added JNI `nativeRunAndroidTool` behind Cargo feature `upstream-engine`.
- Uses the real upstream `Engine`, `Session::isolated`, `Engine::call`, and `ToolOutput::to_json`.
- Allows only this read-only Android tool allowlist:
  - `android_package_show`
  - `android_classes_find`
  - `android_class_show`
  - `android_class_users_find`
  - `android_resources_read`
  - `android_components_list`
- The selected document is staged in the app-provided cache directory, passed to the engine as an explicit `path`, then the temporary input file is deleted.
- Does not expose general process, filesystem-write, device-control, or arbitrary engine tools through this JNI method.
- `nativeToolCatalog` is restricted to the same Android read-only allowlist.

### 3. Android UI
- Added class/method inputs and a Dalvik instruction listing panel.
- Added an original-engine tool ID + JSON parameter panel.
- App cache path is passed to JNI for temporary staging.

## Build and integration

The project must be placed at `apps/craft-anything-android` inside a clone of `storytold/craft-anything` so the optional upstream Cargo path dependencies resolve.

Prerequisites:
- Android Studio / Android SDK
- Android NDK
- Rust and Android Rust targets
- `cargo-ndk`
- Gradle

Build the JNI library and debug APK:
```bash
./build-apk.sh
```

To attempt linking the upstream engine as well:
```bash
CRAFT_ANDROID_WITH_UPSTREAM_ENGINE=1 ./native/build-android.sh
gradle --no-daemon :app:assembleDebug
```

The engine feature remains opt-in. `crates/platform` currently depends on process/PTY crates and has not been validated on Android; if it fails to compile, the required next task is to gate or replace non-Android process/PTY backends, not to disable safety checks.

## Verification status and remaining work

- This environment does not have Rust, Gradle, Android SDK/NDK installed, so neither Rust compilation nor APK assembly could be run here.
- The default build enables the upstream formats feature but leaves the upstream engine feature off.
- The engine-dispatch JNI path is implemented but is not runtime-verified until built with `CRAFT_ANDROID_WITH_UPSTREAM_ENGINE=1` on an Android-compatible toolchain.
- Overload selection UI, complete class/member navigation, progress/cancellation, and the rest of the desktop engine tools are not yet ported.
- This phase does not claim a finished production APK.
