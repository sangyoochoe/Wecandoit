# Phase 9 — mobile-first UI and runtime optimization

## UX redesign

The former single long scrolling page has been split into four focused mobile destinations:

1. **Analyze** — choose a file, run offline parsing, inspect the summary, and jump to deeper tools or AI.
2. **Tools** — method disassembly and the explicit native-engine tool entry point.
3. **AI** — a focused question-and-answer surface with the analysis context.
4. **Settings** — provider, model, endpoint, encrypted API key, and runtime status.

A bottom navigation bar keeps the primary destinations reachable with one hand. The selected file and analysis state remain shared while switching destinations. The top bar keeps the active file visible without taking up a large portion of the screen.

## Runtime and memory improvements

- File metadata is queried before reading. When a provider reports a reliable size, the app preallocates the exact byte array instead of growing a `ByteArrayOutputStream` and then making a second full-size copy.
- Unknown-size streams still use a bounded streaming read; both paths enforce the 64 MiB ceiling.
- AI text-only requests no longer load the full APK into memory when the Rust tool host is unavailable. The file is read for an AI request only when tool execution is actually available.
- The SAF read grant is persisted when the provider supports it, so the chosen document can survive activity recreation and app restarts.
- The amount of eagerly composed disassembly output is capped at 120 rows in the UI. Existing parser output and native result limits remain in force.
- Release builds enable R8 code shrinking and resource shrinking. JNI bridge names and persisted provider enum names are explicitly kept against obfuscation.
- Native ABI filters match the existing native build script (`arm64-v8a`, `x86_64`) to avoid packaging unused ABIs.

## Preserved behavior

- Existing Rust JNI parser and method disassembly entry points remain in use.
- Existing encrypted AI provider settings and model discovery remain available.
- The UI continues to state when the upstream Rust engine feature is not enabled; it does not present an unavailable tool as operational.

## Validation and known limits

- Source-level checks only; no Gradle, Kotlin compiler, Android SDK/NDK or Rust toolchain is available in the current environment.
- No APK assembly, emulator test, memory benchmark, frame-time benchmark or live API request is claimed.
- The app still has a 64 MiB input ceiling and currently reads a selected file into a byte array before JNI calls. A future streaming parser/JNI API would reduce peak memory further.
- The analysis detail renderer still uses bounded Compose columns rather than a full virtualized tree for every nested JSON section.
- This is a mobile-first UI and memory-path improvement, not a claim that the upstream desktop application has reached full feature parity.
