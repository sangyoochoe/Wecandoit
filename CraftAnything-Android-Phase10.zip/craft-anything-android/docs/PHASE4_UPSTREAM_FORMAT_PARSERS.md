# Phase 4 — Upstream Rust format parser integration

## Connected
- Optional `upstream-formats` Cargo feature points to the repository's `crates/formats`.
- JNI `nativeAnalyzeAndroid(fileName, bytes)` calls the original pure-Rust parser crate.
- Bare DEX: `craft_anything_formats::dex::parse` validates structure and returns version, checksum status, string/type/method/class counts, and up to 250 class descriptors.
- APK/ZIP: `craft_anything_formats::zip::parse` validates the central directory, lists entries, identifies `AndroidManifest.xml` and `resources.arsc`, extracts bounded DEX members with CRC verification, and parses up to 64 DEX files (each capped at 32 MiB).
- Kotlin invokes the deeper parser from the selected-file flow and shows the returned JSON alongside the first-pass signature/hash result.
- No subprocess or target execution is involved.

## Build
From the cloned upstream repository, install this app folder at `apps/craft-anything-android`, then run:
`CRAFT_ANDROID_WITH_UPSTREAM_FORMATS=1 ./apps/craft-anything-android/native/build-android.sh`

The Cargo path dependency `../../../crates/formats` assumes that exact placement. The optional engine dependency remains separate and is not enabled by this phase.

## Safety bounds
- Input file: 64 MiB maximum.
- ZIP listing: 20,000 entries.
- DEX members: 32 MiB each; up to 64 DEX members.
- Class display: up to 250 classes for standalone DEX, 100 per APK DEX member.
- ZIP member CRC is verified by the upstream reader.

## Not yet connected
- Binary AndroidManifest.xml decoding (`axml`) and resource table decoding (`arsc`).
- Full `android_tools` engine invocation / evidence ledger.
- UI-native rendering of class lists; current result is structured JSON.

## Validation
Not compiled or run in this environment. Android SDK/NDK, Rust Android targets and cargo-ndk are required for device validation.
