# Phase 3 — Android file analysis

## Implemented
- Android Storage Access Framework (`OpenDocument`) file picker.
- Reads selected content through `ContentResolver`; no broad storage permission is requested.
- Reads on `Dispatchers.IO`, with a strict 64 MiB cap.
- Sends the bounded byte array and display name through JNI to Rust.
- Rust returns JSON with byte length, SHA-256, signature-based type hint and explicit limitations.
- The selected file is never executed.

## Detection scope
- DEX: `dex\\n` signature.
- ELF: `0x7f ELF` signature.
- PE: MZ header plus PE signature at the declared offset.
- APK: ZIP local-file signature plus `.apk` display name (not yet manifest validation).
- ZIP: ZIP local-file signature.

This is a first-pass classifier, not a substitute for the repository's full parsers. The upstream repository contains pure format parsers in `crates/formats` and Android tools in `crates/engine/src/tools/android_tools.rs`, including `android_package_show`, `android_classes_find`, `android_class_show`, `android_method_show`, and `android_resources_read`. The next integration step is to make those crates Android-compatible and expose a narrow allowlisted invocation API.

## Build / validation status
Not compiled in this environment: Android Gradle and Rust toolchains are unavailable here. Build and runtime verification are still required on a machine with Android SDK/NDK, Rust targets and cargo-ndk installed.
