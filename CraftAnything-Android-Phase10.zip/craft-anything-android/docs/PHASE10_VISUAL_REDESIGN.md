# Phase 10 — Craft Anything Android visual redesign

## What changed
- Reworked the Compose visual system around the upstream desktop design-system guidance.
- Adopted the upstream Studio dark direction: warm graphite canvas, slightly raised cards and fields, restrained indigo/blue accent, readable contrast, and compact rounded geometry.
- Added a consistent app chrome treatment: compact wordmark, current-file subtitle, and a quieter bottom navigation bar.
- Improved hierarchy with section eyebrows, clearer page titles, consistent card surfaces, and larger touch targets for primary actions.
- Refined the home/analyze entry point, tool workspace, AI assistant, and settings headings without changing the underlying analysis/provider behavior.
- Added a working Simple / Advanced mode switch inspired by the upstream title-bar mode selector. Simple mode keeps Home, AI, and Settings visible; Advanced mode exposes the analysis-tools destination.
- Kept only capabilities that already exist in the Android port. No unsupported project history, build pipeline, or fake Study/Build/Check workflow was added.

## Upstream design references
The redesign follows the concepts documented in the upstream `docs/design-system.md` and `crates/ui-egui/src/theme.rs`:
- a shared token scale and consistent component treatment;
- warm graphite dark surfaces and indigo/blue accent;
- clear distinction between canvas, card, and interactive field surfaces;
- sentence-case labels, restrained corners, and consistent spacing;
- Simple mode for plain-language work and Advanced mode for tools/evidence/logs as a product direction.

This is a mobile adaptation, not a pixel-perfect copy of the desktop egui interface. Android uses Material 3 and Compose.

## Validation
- Source-level edits only.
- Checked Kotlin source delimiter balance and XML parsing.
- Gradle/Android SDK/NDK/Rust toolchain are not available in this environment, so no APK build, emulator screenshot, or device verification is claimed.
