# Phase 5 — Manifest, resources, and results UI

## Implemented in this phase

- The JNI Android analysis entry point now uses the upstream `craft-anything-formats` AXML parser for `AndroidManifest.xml`.
- Manifest facts are extracted with the upstream `axml::manifest` helper:
  - package and version
  - min/target/max SDK
  - requested and declared permissions
  - requested features
  - application flags
  - activities, aliases, services, receivers, and providers
  - exported state and intent-filter-derived facts as exposed by the parser
- `resources.arsc` is parsed with the upstream ARSC parser using a 50,000-entry cap.
- Resource output includes package/type metadata and up to 300 parsed resource entries.
- The Compose screen now renders a readable summary instead of showing only the raw JSON blob.
- DEX summaries continue to show file version, class/method counts, bounded class-name previews, and up to 100/150 method signatures with code-unit/register metadata. This is a method inventory, not full bytecode disassembly.

## Safety and resource bounds

- Selected file: 64 MiB maximum (existing SAF read limit).
- ZIP entries: parser limit of 20,000.
- Manifest member: 8 MiB.
- `resources.arsc`: 32 MiB.
- DEX member: 32 MiB.
- ARSC decoded entries: 50,000.
- UI previews are capped; the screen does not attempt to render every archive/resource/class entry.
- The selected APK/DEX is parsed offline and is never executed.

## Not included yet

- Full Dalvik instruction disassembly / method-body viewer (this phase only inventories method signatures and code-item metadata).
- Resource resolution from resource IDs into all locale/configuration variants in the UI.
- Signing certificate verification UI and native library deep analysis.
- AI/agent execution and upstream engine tool invocation.
- Gradle/NDK/Rust build validation. The development container used for this project does not have the required Rust/Gradle/Android toolchains installed.

## Integration note

The native crate's `upstream-formats` feature depends on the original repository workspace at `crates/formats`. Install this Android project under `apps/craft-anything-android` in the cloned `storytold/craft-anything` repository before building with `native/build-android.sh`.
