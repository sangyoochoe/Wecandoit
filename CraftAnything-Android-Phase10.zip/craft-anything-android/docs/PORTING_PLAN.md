# Android porting plan

## Phase 1 — Android shell
- Native Kotlin Activity and Compose UI
- SAF document picker; no broad storage permission
- JNI smoke test and ABI packaging

## Phase 2 — headless Rust facade
- Keep UI and Android APIs out of engine crates
- Audit `platform` dependencies for Android support
- Expose a small typed JNI API: create session, inspect target, list evidence, start/cancel job,
  answer question, approve action, list/open project
- Move all long-running work off the Android main thread
- Add lifecycle-safe cancellation and progress events

## Phase 3 — platform adapters
- Replace desktop-only dialogs and process assumptions with capability-based adapters
- Android document URI access through Kotlin ContentResolver, passed to Rust as bounded streams or
  app-private staged files
- Android process execution policy: no assumed shell, no bundled desktop coding-agent CLI
- Secure API-key storage via Android Keystore; never log credentials

## Phase 4 — AI build execution
- Local coding-agent CLIs are generally not available as desktop equivalents on Android.
- First-class on-device mode should support a local model/runtime only where hardware permits.
- Optional remote agent execution must be explicit, authenticated, and user-configured. This is not
  the same as making the product a thin remote UI; analysis and supported engine tools remain local.

## Phase 5 — release
- Build arm64-v8a first, then x86_64 emulator and armeabi-v7a if justified
- Test Android 8 through current Android release, file picker, keyboard/IME, process lifecycle,
  low-memory recovery, and large APK limits
- Produce signed release APK/AAB and publish checksums


## Phase 8 — upstream AI parity (audit completed; integration pending)

See [PHASE8_UPSTREAM_AI_PARITY.md](PHASE8_UPSTREAM_AI_PARITY.md). The upstream AI source has been inspected and the exact parity gaps and Android platform blockers are documented. This is not a claim that the upstream `craft-anything-ai` crate is integrated or that the app builds. The next implementation milestone is to extract platform-independent AI core modules and add Android platform traits before exposing the upstream `Conversation`/`AgentEvent` lifecycle through JNI.
