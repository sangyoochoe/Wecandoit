# Phase 8 — Upstream AI parity audit

## Status

**Not yet a 100% port.** This phase records a source-verified parity boundary and the Android work required before the upstream `craft-anything-ai` crate can be enabled. It deliberately does not claim that the upstream AI crate has been integrated or that an Android APK builds.

## Source-verified upstream architecture

The upstream AI crate (`crates/ai`) exposes `AiHub` and `Conversation` as its UI boundary. Its documented design is asynchronous: the UI starts a conversation, sends messages, and polls `AgentEvent` values while network and subprocess work runs on background workers.

The built-in agent loop in `crates/ai/src/agent.rs` is not just an HTTP tool-call loop. Its core contracts include:

- `Conversation`: `send`, `retry`, `poll`, `answer_consent`, `refuse_consent`, `stop`, `is_busy`, plus session identity/loss reporting.
- `AgentEvent`: streamed text, status, process output, tool start/finish, consent requests, turn completion with token/cost data, and structured errors with remediation/log references.
- `ToolHost`: registry-derived tool definitions, toolset membership, calls with cancellation and consent, journal events, investigation context, clean-room state and tool titles.
- `EngineHost`: adapts the upstream `Engine` to `ToolHost`; invokes tools with `Caller::Agent`, `CancelToken` and `Consent`.
- `ReadOnlyHost`: filters tools by effect and refuses tools that change state.
- `AgentLoop`: maintains message history, model fallback chain, enabled toolsets, system prompt, context budget, cancellation, consent waiters, transcript, failure state and usage meter.
- Context management: server context-window discovery, trimming tool results/history, optional model-written summaries, and a bounded per-turn result budget.
- Tool orchestration: meta-tools `list_toolsets` and `enable_toolset`, schema normalization, consent gates, tool result pairing and bounded result serialization.
- Provider model abstraction: `ChatModel`, `TurnRequest`, `TurnResult`, deltas, stop reasons, usage and optional context-window reporting.

## Android implementation parity

| Area | Phase 7 Android implementation | Upstream parity |
|---|---|---|
| Provider setup | OpenAI-compatible and Anthropic HTTP requests | Partial |
| Provider catalogue | Fixed enum and optional `/models` request | Partial; no upstream detection/config model |
| Secret storage | Android Keystore AES-GCM encrypted preference | Platform-appropriate replacement, not upstream KeyStore |
| Agent loop | Bounded request/tool-call loop | Partial; lacks upstream state machine |
| Tool definitions | Six Android read-only tool names | Partial; not full `Registry`/`Toolset` catalogue |
| Tool execution | JNI call to `nativeRunAndroidTool` when engine feature is enabled | Partial; no upstream `ToolHost` contract |
| Consent | No complete consent handshake | Missing |
| Cancellation | No upstream `CancelToken` propagation | Missing |
| Streaming | Whole response returned after HTTP completes | Missing |
| Retry/fallback | No upstream failure classification/fallback chain | Missing |
| Context budgeting | Fixed character caps | Missing upstream token/window-aware trimming |
| Transcript/journal | Not persisted as upstream transcript/journal | Missing |
| Token/cost metering | Not implemented | Missing |
| Toolset discovery/enablement | Fixed allowlist | Missing |
| Agent CLI / ACP | Not implemented | Platform-specific; requires a separate Android decision |

## Android blockers in the upstream crate

`crates/ai/Cargo.toml` directly depends on:

- `craft-anything-engine`
- `craft-anything-engines`
- `craft-anything-formats`
- `craft-anything-platform`
- `ureq`, `dirs`, `toml`, `regex`, `schemars`, serialization and logging dependencies

It also declares OS-specific `keyring` dependencies for Linux, macOS and Windows, but no Android keyring implementation. The upstream crate's public source includes CLI agent adapters, SSH, subprocess-oriented integrations and other desktop-oriented functionality. Enabling the whole crate for Android without first isolating platform-only modules is therefore not a verified or safe build path.

## Required implementation sequence for a faithful Android port

1. **Split platform-independent AI core from platform adapters.** Keep `model`, `agent`, `context`, `prompt`, provider HTTP protocol code, pricing and failure classification in the shared Rust core. Move keyring, CLI process, SSH and desktop discovery behind platform traits/features.
2. **Add Android platform adapter.** Implement the upstream `KeyStore` contract with an Android Keystore-backed JNI/Kotlin adapter. Do not put plaintext API keys in Rust config or logs.
3. **Expose upstream AI types through a stable JNI boundary.** Prefer opaque native conversation handles and event polling over reimplementing the agent loop in Kotlin. Define lifecycle-safe create/send/poll/consent/stop/destroy calls.
4. **Connect `EngineHost` to the Android session.** Build one persistent `Engine`/`Session` per analysis workspace; do not create a fresh empty engine for every tool call. Use the real registry and `Caller::Agent`.
5. **Preserve policy and permissions.** Use upstream tool effects, consent requirements and `ReadOnlyHost` semantics. Keep Android-only tool access explicit until the full registry can safely run on Android.
6. **Port transcript and journal storage.** Use app-private storage and SAF document access only where the user explicitly chooses an export/import location.
7. **Port streaming and cancellation.** Deliver `AgentEvent` incrementally to Compose and propagate stop/cancel into the model request and tool execution.
8. **Build and test on Android targets.** Verify Rust target triples, NDK linker configuration, all transitive native dependencies, JNI lifecycle, provider protocol fixtures, consent tests, cancellation tests and an actual APK on an emulator/device.

## Completion criteria

The Android port can be called behaviorally equivalent only when the shared upstream agent loop is actually used (not a second Kotlin implementation), the same registry/host contracts and conversation events are represented, the Android-specific platform traits are implemented, and automated parity tests cover tool calling, consent, retry, stop, context trimming, transcripts, errors and usage reporting.

## Current validation boundary

- Upstream source inspected: `crates/ai/src/lib.rs`, `crates/ai/src/agent.rs`, `crates/ai/Cargo.toml`, and `crates/engine/src/session.rs`.
- Phase 7 source remains a focused Android provider/agent implementation.
- No Rust/Gradle/Android SDK/NDK toolchain is available in the current build environment.
- No Android compilation, APK assembly, device test or live provider request is claimed.
