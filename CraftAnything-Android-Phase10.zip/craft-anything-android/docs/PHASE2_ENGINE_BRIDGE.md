# Phase 2 — Rust engine bridge

## What is implemented
- A JNI method returns bridge status.
- A JNI method returns a JSON tool catalog.
- With the `upstream-engine` feature, the catalog is obtained from a real
  `craft_anything_engine::Engine` and its `Registry::all()` entries.
- Kotlin calls both methods and shows the catalog payload in the app.
- Engine tool execution is deliberately not exposed yet.

## Install into the upstream repository
Copy this project directory to `apps/craft-anything-android` in a clone of
`storytold/craft-anything`. The optional Cargo path dependency in
`native/Cargo.toml` expects that location.

Build the JNI-only bridge:
```bash
cd apps/craft-anything-android
./native/build-android.sh
```

Attempt the real upstream engine feature only after platform compatibility work:
```bash
CRAFT_ANDROID_WITH_UPSTREAM_ENGINE=1 ./native/build-android.sh
```

## Why full engine linking is gated
The upstream engine depends on `craft-anything-platform`. Its current manifest includes
`process-wrap` and `portable-pty`, and the AI crate has OS-specific keychain adapters for
Linux/macOS/Windows but no Android Keystore adapter. The Android build must not silently
reuse Linux keyring assumptions or provide unsafe process behavior.

The feature is therefore opt-in. The default Android build remains a JNI smoke-test bridge.
When Android-safe implementations are added upstream, enable the feature and verify the
cross-build for `aarch64-linux-android` and `x86_64-linux-android`.

## Next step
Port the platform services needed by offline file analysis, then expose a small allowlisted
`Engine::call` surface with typed request/response JSON, cancellation, progress, bounded
payload sizes and explicit consent for side-effecting tools. Do not expose arbitrary tool
execution from the Android UI.
