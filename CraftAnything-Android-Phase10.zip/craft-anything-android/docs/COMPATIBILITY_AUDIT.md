# Upstream Android compatibility audit

Audit performed against the repository's default branch manifests and source files on 2026-11-16.

## Findings

### Reusable candidates
- `crates/formats`, `crates/disasm`, and `crates/js` are the best first candidates: their documented
  responsibilities are primarily parsing/analysis and do not inherently require a desktop window.
- `crates/engine` is the shared headless dispatch/session layer, but its platform and storage
  dependencies must be checked before compiling it for Android.
- The workspace explicitly enforces a headless-first architecture: UI is a thin client and
  orchestration/process control must not live in UI crates.

### Confirmed Android blockers / work
1. `crates/platform/Cargo.toml` unconditionally depends on `process-wrap` and `portable-pty`.
   The platform crate also has Unix-target dependencies. Android is Unix-like for Rust cfg purposes,
   but that does not prove that these process and PTY abstractions behave correctly on Android.
2. `crates/ai/src/keys.rs` compiles its OS keychain adapter only for Linux, macOS and Windows.
   Android has no matching adapter in the current source. Add a Kotlin Android Keystore adapter
   behind a narrow platform interface; do not pretend Linux Secret Service is Android Keystore.
3. `crates/ui-egui/Cargo.toml` includes native desktop dialogs and clipboard integration for
   non-WASM targets. `apps/craft-anything/Cargo.toml` is the desktop executable and should not be
   the Android application entry point.
4. `crates/ai` includes local agent CLI and SSH workflows. Android cannot assume desktop agent CLIs,
   shell utilities, or an SSH environment are installed.
5. Android file access should use Storage Access Framework document URIs and ContentResolver,
   not broad filesystem permissions or assumptions about stable filesystem paths.

## Recommended port boundary

- Keep parsers and pure analysis crates in Rust.
- Add an Android host app in Kotlin/Compose.
- Add a small Rust Android facade that owns an `Engine` and exposes typed, bounded operations over
  JNI. Long-running operations must run off the Android main thread and expose cancellation/progress.
- Implement Android-specific file/document access and secret storage in Kotlin.
- Initially expose only offline file/APK analysis. Add HTTP/web inspection next. Add API-backed AI
  after secure key storage and network lifecycle handling. Treat local CLI agents and desktop process
  orchestration as unsupported until separately ported.

## Validation still required

This was a source/manifests audit, not a successful Android cross-build. No Android SDK/NDK or Rust
toolchain is installed in the build environment used for this audit. The upstream workspace has not
yet been compiled for `aarch64-linux-android` or `x86_64-linux-android`.
