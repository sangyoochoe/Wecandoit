# Phase 7 review notes

## Changes in this review pass

- Repaired `AndroidManifest.xml` into valid XML and confirmed the INTERNET permission is present.
- Kept the API provider implementation focused on the upstream API-backend path: OpenAI-compatible Chat Completions and Anthropic Messages.
- Added model discovery for OpenAI-compatible `/models` and Anthropic `/v1/models`; manual model entry remains available if a server does not expose discovery.
- Normalized Anthropic base URLs so both `https://api.anthropic.com` and `https://api.anthropic.com/v1` work.
- Validated endpoint schemes and rejected URL user-info, query strings and fragments. Cloud endpoints require HTTPS; HTTP is accepted only for Ollama/custom endpoints resolving to localhost or private/link-local addresses.
- Bounded request and response bodies to 2 MiB and model-list requests to a 2 MiB response cap.
- Removed the hard-coded `temperature` parameter from OpenAI-compatible requests to improve compatibility with reasoning models and local servers.
- AI tool schemas are now sent only if the JNI tool catalog reports that the upstream engine is connected. Without it, the system prompt explicitly tells the model not to claim live APK inspection.
- Preserved the Android Keystore AES-GCM API-key storage and the six-tool read-only allowlist.

## Deliberate scope limits

This is an Android-native API provider + bounded tool-calling loop, not a line-for-line port of upstream `crates/ai`. Streaming deltas, fallback chains, usage/cost metering, transcript persistence, automatic context-window fitting, provider capability metadata, ACP and CLI agents remain unported.

## Verification

- AndroidManifest XML parsed successfully.
- Kotlin source delimiters/comments/strings passed a static balance check.
- No `gradle`, `cargo`, `rustc`, Android SDK or NDK executable is available in this environment. Therefore no Kotlin/Rust compilation, APK assembly, live provider request or device test is claimed.
- The optional upstream engine JNI feature remains a separate Android compatibility gate. If it is disabled, AI chat still works with supplied analysis context, but the AI is not offered live Rust tools.
