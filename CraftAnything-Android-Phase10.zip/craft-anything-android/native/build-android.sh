#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT/native"

if ! command -v cargo-ndk >/dev/null 2>&1; then
  echo "cargo-ndk is required: cargo install cargo-ndk" >&2
  exit 1
fi

rustup target add aarch64-linux-android x86_64-linux-android

FEATURE_ARGS=()
if [[ "${CRAFT_ANDROID_WITH_UPSTREAM_ENGINE:-0}" == "1" ]]; then
  FEATURE_ARGS+=(--features upstream-engine)
fi
if [[ "${CRAFT_ANDROID_WITH_UPSTREAM_FORMATS:-1}" == "1" ]]; then
  FEATURE_ARGS+=(--features upstream-formats)
fi

cargo ndk -t arm64-v8a -t x86_64 -o "$ROOT/app/src/main/jniLibs" build --release "${FEATURE_ARGS[@]}"
echo "Rust JNI libraries copied to app/src/main/jniLibs"
