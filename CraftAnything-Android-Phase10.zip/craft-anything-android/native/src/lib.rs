use jni::objects::{JClass, JString};
use jni::sys::jstring;
use jni::JNIEnv;

fn to_java_string(env: &mut JNIEnv, value: &str) -> jstring {
    match env.new_string(value) {
        Ok(value) => value.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_ai_storyteller_craftanything_NativeBridge_nativeStatus(
    mut env: JNIEnv,
    _class: JClass,
) -> jstring {
    let status = if cfg!(feature = "upstream-engine") {
        "Rust JNI bridge loaded; upstream Craft Anything engine feature enabled."
    } else {
        "Rust JNI bridge loaded; upstream engine feature is not enabled."
    };
    to_java_string(&mut env, status)
}

/// Returns a JSON array describing the actual upstream engine tool registry.
/// This is intentionally read-only: tool execution is a later phase after Android
/// storage, process, consent and cancellation semantics are implemented.
#[unsafe(no_mangle)]
pub extern "system" fn Java_ai_storyteller_craftanything_NativeBridge_nativeToolCatalog(
    mut env: JNIEnv,
    _class: JClass,
) -> jstring {
    #[cfg(feature = "upstream-engine")]
    let payload = {
        use craft_anything_engine::{Engine, Session, Settings};
        let engine = Engine::new(Session::new(Settings::default()));
        let registry = engine.registry();
        let allowed = [
            "android_package_show", "android_classes_find", "android_class_show",
            "android_class_users_find", "android_resources_read", "android_components_list"
        ];
        let tools: Vec<serde_json::Value> = registry
            .all()
            .iter()
            .filter(|spec| allowed.contains(&spec.id))
            .map(|spec| {
                serde_json::json!({
                    "id": spec.id,
                    "title": spec.title,
                    "summary": spec.summary,
                    "inputSchema": registry.input_schema(spec)
                })
            })
            .collect();
        serde_json::json!({
            "connected": true,
            "count": tools.len(),
            "tools": tools
        })
        .to_string()
    };

    #[cfg(not(feature = "upstream-engine"))]
    let payload = serde_json::json!({
        "connected": false,
        "count": 6,
        "tools": [
            {"id":"android_package_show","title":"APK 패키지 정보","summary":"매니페스트, 서명, DEX 및 네이티브 라이브러리"},
            {"id":"android_classes_find","title":"클래스 찾기","summary":"APK/DEX의 클래스 검색"},
            {"id":"android_class_show","title":"클래스 상세","summary":"상속, 필드, 메서드 및 어노테이션"},
            {"id":"android_class_users_find","title":"클래스 사용처","summary":"클래스 참조 지점 검색"},
            {"id":"android_resources_read","title":"리소스 분석","summary":"resources.arsc 및 XML 리소스"},
            {"id":"android_components_list","title":"컴포넌트 목록","summary":"exported 및 intent-filter 확인"}
        ],
        "reason": "The Android tool catalog is shown, but execution requires a native library built with --features upstream-engine."
    })
    .to_string();

    to_java_string(&mut env, &payload)
}


/// Bounded, offline first-pass file inspection. It never executes the selected file.
#[unsafe(no_mangle)]
pub extern "system" fn Java_ai_storyteller_craftanything_NativeBridge_nativeInspectBytes(
    mut env: JNIEnv,
    _class: JClass,
    jname: JString,
    jbytes: jni::objects::JByteArray,
) -> jstring {
    let name = env.get_string(&jname).map(|v| v.to_string_lossy().into_owned())
        .unwrap_or_else(|_| "selected-file".to_string());
    let bytes = match env.convert_byte_array(&jbytes) {
        Ok(v) => v,
        Err(_) => return to_java_string(&mut env, r#"{"ok":false,"error":"Unable to read file bytes"}"#),
    };

    const MAX_BYTES: usize = 64 * 1024 * 1024;
    if bytes.len() > MAX_BYTES {
        return to_java_string(&mut env, r#"{"ok":false,"error":"File exceeds 64 MiB inspection limit"}"#);
    }

    let lower = name.to_ascii_lowercase();
    let kind = if bytes.starts_with(b"dex\n") {
        "DEX"
    } else if bytes.starts_with(b"\x7fELF") {
        "ELF"
    } else if bytes.starts_with(b"MZ") && bytes.len() >= 0x40
        && bytes.get(0x3c..0x40).and_then(|v| v.try_into().ok())
            .map(u32::from_le_bytes)
            .and_then(|off| bytes.get(off as usize..off as usize + 4))
            == Some(b"PE\0\0".as_slice()) {
        "PE"
    } else if bytes.starts_with(b"PK\x03\x04") && lower.ends_with(".apk") {
        "APK (ZIP container; manifest not yet decoded)"
    } else if bytes.starts_with(b"PK\x03\x04") {
        "ZIP"
    } else if bytes.starts_with(b"MZ") {
        "DOS/PE candidate (header needs deeper parsing)"
    } else {
        "Unknown"
    };

    use sha2::{Digest, Sha256};
    let digest = Sha256::digest(&bytes);
    let sha256 = digest.iter().map(|b| format!("{b:02x}")).collect::<String>();
    let payload = serde_json::json!({
        "ok": true,
        "name": name,
        "sizeBytes": bytes.len(),
        "sha256": sha256,
        "detectedFormat": kind,
        "analysisLevel": "signature-and-hash",
        "executed": false,
        "limitations": [
            "APK is identified by ZIP signature and .apk filename only; AndroidManifest.xml is not decoded yet.",
            "DEX, ELF and PE are identified by their leading signatures only; structural validation is not yet performed."
        ]
    }).to_string();
    to_java_string(&mut env, &payload)
}


/// Invoke the upstream pure-Rust DEX and ZIP parsers. No process is spawned.
#[unsafe(no_mangle)]
pub extern "system" fn Java_ai_storyteller_craftanything_NativeBridge_nativeAnalyzeAndroid(
    mut env: JNIEnv,
    _class: JClass,
    jname: JString,
    jbytes: jni::objects::JByteArray,
) -> jstring {
    let name = env.get_string(&jname).map(|v| v.to_string_lossy().into_owned())
        .unwrap_or_else(|_| "selected-file".to_string());
    let bytes = match env.convert_byte_array(&jbytes) {
        Ok(v) => v,
        Err(_) => return to_java_string(&mut env, r#"{"ok":false,"error":"Unable to read file bytes"}"#),
    };
    const MAX_INPUT: usize = 64 * 1024 * 1024;
    const MAX_DEX_MEMBER: u64 = 32 * 1024 * 1024;
    if bytes.len() > MAX_INPUT {
        return to_java_string(&mut env, r#"{"ok":false,"error":"File exceeds 64 MiB limit"}"#);
    }

    #[cfg(feature = "upstream-formats")]
    let payload = {
        use craft_anything_formats::{dex, zip};
        use serde_json::json;
        if dex::is_dex(&bytes) {
            match dex::parse(&bytes) {
                Ok(parsed) => {
                    let classes: Vec<String> = parsed.classes.iter().take(250)
                        .map(|class| parsed.class_name(class)).collect();
                    let classes_truncated = parsed.classes.len() > classes.len();
                    let mut method_previews = Vec::new();
                    for class in &parsed.classes {
                        let class_name = parsed.class_name(class);
                        let class_data = parsed.class_data(class);
                        for method in class_data.direct_methods.iter().chain(&class_data.virtual_methods) {
                            if method_previews.len() >= 150 { break; }
                            let code = parsed.code(method.code_off);
                            method_previews.push(json!({
                                "class": &class_name,
                                "signature": parsed.method_signature(method),
                                "codeUnits": code.as_ref().map(|c| c.insns.len()).unwrap_or(0),
                                "registers": code.as_ref().map(|c| c.registers),
                                "hasCode": code.is_some()
                            }));
                        }
                        if method_previews.len() >= 150 { break; }
                    }
                    json!({
                        "ok": true,
                        "format": "DEX",
                        "parser": "craft-anything-formats::dex",
                        "dexVersion": parsed.header.version,
                        "fileSize": parsed.header.file_size,
                        "checksumValid": parsed.header.checksum_ok,
                        "stringCount": parsed.header.string_ids,
                        "typeCount": parsed.header.type_ids,
                        "methodCount": parsed.header.method_ids,
                        "classCount": parsed.header.class_defs,
                        "classes": classes,
                        "classesTruncated": classes_truncated,
                        "methodPreview": method_previews,
                        "methodPreviewLimit": 150,
                        "warnings": parsed.warnings,
                        "executed": false
                    }).to_string()
                }
                Err(error) => json!({"ok":false,"format":"DEX","parser":"craft-anything-formats::dex","error":error.to_string(),"executed":false}).to_string()
            }
        } else if bytes.starts_with(b"PK\x03\x04") || bytes.starts_with(b"PK\x05\x06") {
            match zip::parse(&bytes, 20_000) {
                Ok(archive) => {
                    let dex_entries: Vec<_> = archive.entries.iter()
                        .filter(|entry| {
                            let n = entry.name.to_ascii_lowercase();
                            n == "classes.dex" || (n.starts_with("classes") && n.ends_with(".dex"))
                        })
                        .take(64)
                        .collect();
                    let mut dex_summaries = Vec::new();
                    let mut dex_errors = Vec::new();
                    for entry in dex_entries {
                        match zip::read_entry(&bytes, entry, MAX_DEX_MEMBER) {
                            Ok(member) => match dex::parse(&member) {
                                Ok(parsed) => {
                                    let mut method_previews = Vec::new();
                                    for class in &parsed.classes {
                                        let class_name = parsed.class_name(class);
                                        let class_data = parsed.class_data(class);
                                        for method in class_data.direct_methods.iter().chain(&class_data.virtual_methods) {
                                            if method_previews.len() >= 100 { break; }
                                            let code = parsed.code(method.code_off);
                                            method_previews.push(json!({
                                                "class": &class_name,
                                                "signature": parsed.method_signature(method),
                                                "codeUnits": code.as_ref().map(|c| c.insns.len()).unwrap_or(0),
                                                "registers": code.as_ref().map(|c| c.registers),
                                                "hasCode": code.is_some()
                                            }));
                                        }
                                        if method_previews.len() >= 100 { break; }
                                    }
                                    dex_summaries.push(json!({
                                        "entry": entry.name,
                                        "sizeBytes": member.len(),
                                        "dexVersion": parsed.header.version,
                                        "classCount": parsed.header.class_defs,
                                        "methodCount": parsed.header.method_ids,
                                        "classes": parsed.classes.iter().take(100).map(|c| parsed.class_name(c)).collect::<Vec<_>>(),
                                        "methodPreview": method_previews,
                                        "checksumValid": parsed.header.checksum_ok,
                                        "warnings": parsed.warnings
                                    }));
                                }
                                Err(error) => dex_errors.push(json!({"entry":entry.name,"error":error.to_string()}))
                            },
                            Err(error) => dex_errors.push(json!({"entry":entry.name,"error":error.to_string()}))
                        }
                    }
                    let manifest_json = archive.entries.iter()
                        .find(|e| e.name == "AndroidManifest.xml")
                        .and_then(|e| zip::read_entry(&bytes, e, 8 * 1024 * 1024).ok())
                        .and_then(|member| craft_anything_formats::axml::parse(&member).ok())
                        .map(|doc| {
                            let facts = craft_anything_formats::axml::manifest(&doc);
                            json!({
                                "package": facts.package,
                                "versionCode": facts.version_code,
                                "versionName": facts.version_name,
                                "minSdk": facts.min_sdk,
                                "targetSdk": facts.target_sdk,
                                "maxSdk": facts.max_sdk,
                                "permissions": facts.uses_permissions.iter().take(250).collect::<Vec<_>>(),
                                "declaredPermissions": facts.declared_permissions.iter().take(100).collect::<Vec<_>>(),
                                "features": facts.uses_features.iter().take(100).collect::<Vec<_>>(),
                                "application": facts.application,
                                "components": facts.components.iter().take(250).collect::<Vec<_>>(),
                                "componentCount": facts.components.len(),
                                "usesLibraries": facts.uses_libraries.iter().take(100).collect::<Vec<_>>(),
                                "xmlTruncated": doc.truncated,
                                "warnings": doc.warnings.iter().take(30).collect::<Vec<_>>(),
                                "xmlPreview": doc.to_xml(24 * 1024)
                            })
                        });
                    let manifest_error = if archive.entries.iter().any(|e| e.name == "AndroidManifest.xml") && manifest_json.is_none() {
                        Some("Manifest member could not be read or decoded as binary XML")
                    } else { None };
                    let resources_json = archive.entries.iter()
                        .find(|e| e.name == "resources.arsc")
                        .and_then(|e| zip::read_entry(&bytes, e, 32 * 1024 * 1024).ok())
                        .and_then(|member| craft_anything_formats::arsc::parse(
                            &member,
                            craft_anything_formats::arsc::Limits { max_entries: 50_000 }
                        ).ok())
                        .map(|table| {
                            json!({
                                "packageCount": table.packages.len(),
                                "packages": table.packages.iter().take(32).collect::<Vec<_>>(),
                                "globalStringCount": table.global_strings,
                                "entryCount": table.entries.len(),
                                "entries": table.entries.iter().take(300).collect::<Vec<_>>(),
                                "truncated": table.truncated,
                                "warnings": table.warnings.iter().take(50).collect::<Vec<_>>()
                            })
                        });
                    let resources_error = if archive.entries.iter().any(|e| e.name == "resources.arsc") && resources_json.is_none() {
                        Some("Resource table could not be read or parsed within the 32 MiB limit")
                    } else { None };
                    let has_manifest = archive.entries.iter().any(|e| e.name == "AndroidManifest.xml");
                    let has_resources = archive.entries.iter().any(|e| e.name == "resources.arsc");
                    let is_apk = has_manifest || name.to_ascii_lowercase().ends_with(".apk");
                    json!({
                        "ok": true,
                        "format": if is_apk {"APK"} else {"ZIP"},
                        "parser": "craft-anything-formats::zip + axml + arsc + dex",
                        "entryCount": archive.entries.len(),
                        "declaredEntryCount": archive.declared_entries,
                        "hasAndroidManifest": has_manifest,
                        "manifest": manifest_json,
                        "manifestError": manifest_error,
                        "hasResourcesTable": has_resources,
                        "resources": resources_json,
                        "resourcesError": resources_error,
                        "dexFiles": dex_summaries,
                        "dexErrors": dex_errors,
                        "archiveWarnings": archive.warnings,
                        "truncated": archive.truncated,
                        "executed": false
                    }).to_string()
                }
                Err(error) => json!({"ok":false,"format":"ZIP/APK candidate","parser":"craft-anything-formats::zip","error":error.to_string(),"executed":false}).to_string()
            }
        } else {
            json!({"ok":false,"error":"This upstream Android parser entry point accepts DEX or ZIP/APK files.","executed":false}).to_string()
        }
    };

    #[cfg(not(feature = "upstream-formats"))]
    let payload = serde_json::json!({
        "ok": false,
        "error": "Upstream format parsers are not linked. Build with CRAFT_ANDROID_WITH_UPSTREAM_FORMATS=1.",
        "executed": false
    }).to_string();

    to_java_string(&mut env, &payload)
}


/// Read-only Android tool dispatch into the original Craft Anything engine.
/// This endpoint is compiled only with `upstream-engine`; callers cannot select non-Android tools.
#[unsafe(no_mangle)]
pub extern "system" fn Java_ai_storyteller_craftanything_NativeBridge_nativeRunAndroidTool(
    mut env: JNIEnv,
    _class: JClass,
    jname: JString,
    jbytes: jni::objects::JByteArray,
    jtool: JString,
    jparams: JString,
    jcache_dir: JString,
) -> jstring {
    let name = env.get_string(&jname).map(|v| v.to_string_lossy().into_owned())
        .unwrap_or_else(|_| "selected.apk".to_string());
    let tool_id = env.get_string(&jtool).map(|v| v.to_string_lossy().into_owned())
        .unwrap_or_default();
    let params_text = env.get_string(&jparams).map(|v| v.to_string_lossy().into_owned())
        .unwrap_or_else(|_| "{}".to_string());
    let cache_dir = env.get_string(&jcache_dir).map(|v| v.to_string_lossy().into_owned())
        .unwrap_or_default();
    if tool_id.len() > 64 || params_text.len() > 64 * 1024 || cache_dir.len() > 4096 || name.len() > 512 {
        return to_java_string(&mut env, r#"{"ok":false,"error":"Tool ID, parameters, cache path, or file name exceeds the input limit"}"#);
    }
    let bytes = match env.convert_byte_array(&jbytes) {
        Ok(v) => v,
        Err(_) => return to_java_string(&mut env, r#"{"ok":false,"error":"Unable to read selected file"}"#),
    };
    const MAX_TOOL_INPUT: usize = 64 * 1024 * 1024;
    if bytes.len() > MAX_TOOL_INPUT {
        return to_java_string(&mut env, r#"{"ok":false,"error":"File exceeds 64 MiB engine-tool limit"}"#);
    }
    let allowed = [
        "android_package_show", "android_classes_find", "android_class_show",
        "android_class_users_find", "android_resources_read", "android_components_list"
    ];
    if !allowed.contains(&tool_id.as_str()) {
        return to_java_string(&mut env, r#"{"ok":false,"error":"Tool is not in the Android read-only allowlist"}"#);
    }

    #[cfg(feature = "upstream-engine")]
    let payload = {
        use craft_anything_engine::{CallOptions, Caller, Engine, Session};
        use serde_json::{Value, json};
        let mut params: Value = match serde_json::from_str(&params_text) {
            Ok(v) if v.is_object() => v,
            Ok(_) => json!({"_invalid":"Tool parameters must be a JSON object"}),
            Err(e) => json!({"_invalid":format!("Invalid JSON parameters: {e}")}),
        };
        if params.get("_invalid").is_some() {
            json!({"ok":false,"error":params["_invalid"]}).to_string()
        } else {
            let cache = std::path::PathBuf::from(&cache_dir);
            let result = (|| -> Result<Value, String> {
                if !cache.is_absolute() { return Err("App cache directory must be an absolute path".into()); }
                std::fs::create_dir_all(&cache).map_err(|e| format!("Cannot create app cache directory: {e}"))?;
                let cache = std::fs::canonicalize(&cache).map_err(|e| format!("Cannot resolve app cache directory: {e}"))?;
                let stamp = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH)
                    .map_err(|e| e.to_string())?.as_nanos();
                let suffix = if name.to_ascii_lowercase().ends_with(".dex") { "dex" } else { "apk" };
                let file_path = cache.join(format!("craft-anything-input-{stamp}.{suffix}"));
                std::fs::write(&file_path, &bytes).map_err(|e| format!("Cannot stage selected file: {e}"))?;
                if !params.is_object() { params = json!({}); }
                if let Some(object) = params.as_object_mut() {
                    object.insert("path".into(), Value::String(file_path.to_string_lossy().into_owned()));
                }
                let state_dir = cache.join("craft-anything-engine-state");
                std::fs::create_dir_all(&state_dir).map_err(|e| format!("Cannot create engine state: {e}"))?;
                let mut session = Session::isolated(&state_dir);
                // The person explicitly selected a file and requested offline analysis.
                session.deep_for_run = Some(true);
                let engine = Engine::new(session);
                let call = engine.call(&tool_id, params, CallOptions::new(Caller::Ui));
                let _ = std::fs::remove_file(&file_path);
                match call {
                    Ok(output) => Ok(output.to_json()),
                    Err(error) => Err(format!("{:?}: {}", error.code, error.message)),
                }
            })();
            match result {
                Ok(value) => json!({"ok":true,"tool":tool_id,"result":value,"executed":false}).to_string(),
                Err(error) => json!({"ok":false,"tool":tool_id,"error":error,"executed":false}).to_string()
            }
        }
    };

    #[cfg(not(feature = "upstream-engine"))]
    let payload = serde_json::json!({
        "ok": false,
        "tool": tool_id,
        "error": "Native library was built without the upstream-engine feature. Android platform compatibility must be resolved before enabling it."
    }).to_string();

    to_java_string(&mut env, &payload)
}

/// Decode a selected method body from a DEX or APK with the upstream Dalvik decoder.
/// This is a bounded, offline read-only operation and never executes the target.
#[unsafe(no_mangle)]
pub extern "system" fn Java_ai_storyteller_craftanything_NativeBridge_nativeDisassembleAndroidMethod(
    mut env: JNIEnv,
    _class: JClass,
    jname: JString,
    jbytes: jni::objects::JByteArray,
    jclass_name: JString,
    jmethod_name: JString,
    overload_index: jni::sys::jint,
    instruction_offset: jni::sys::jint,
    instruction_limit: jni::sys::jint,
) -> jstring {
    let name = env.get_string(&jname).map(|v| v.to_string_lossy().into_owned())
        .unwrap_or_else(|_| "selected-file".to_string());
    let class_name = env.get_string(&jclass_name).map(|v| v.to_string_lossy().into_owned())
        .unwrap_or_default();
    let method_name = env.get_string(&jmethod_name).map(|v| v.to_string_lossy().into_owned())
        .unwrap_or_default();
    if class_name.len() > 512 || method_name.len() > 256 || name.len() > 512 {
        return to_java_string(&mut env, r#"{"ok":false,"error":"Class, method, or file name exceeds the input limit"}"#);
    }
    let bytes = match env.convert_byte_array(&jbytes) {
        Ok(v) => v,
        Err(_) => return to_java_string(&mut env, r#"{"ok":false,"error":"Unable to read selected file"}"#),
    };
    if bytes.len() > 64 * 1024 * 1024 {
        return to_java_string(&mut env, r#"{"ok":false,"error":"File exceeds 64 MiB limit"}"#);
    }
    #[cfg(feature = "upstream-formats")]
    let payload = {
        use craft_anything_formats::{dex, dex_ops, zip};
        use serde_json::json;
        let result = (|| -> Result<serde_json::Value, String> {
            let mut members: Vec<(String, Vec<u8>)> = Vec::new();
            if dex::is_dex(&bytes) {
                members.push((name.clone(), bytes.clone()));
            } else {
                let archive = zip::parse(&bytes, 20_000).map_err(|e| e.to_string())?;
                for entry in archive.entries.iter().filter(|e| {
                    let n=e.name.to_ascii_lowercase();
                    n=="classes.dex" || (n.starts_with("classes") && n.ends_with(".dex"))
                }).take(64) {
                    let data=zip::read_entry(&bytes, entry, 32*1024*1024).map_err(|e| e.to_string())?;
                    members.push((entry.name.clone(), data));
                }
            }
            for (dex_name, data) in members {
                let parsed=dex::parse(&data).map_err(|e| e.to_string())?;
                let want=dex::to_descriptor(&class_name);
                let Some(class)=parsed.find_class(&want) else { continue };
                let class_data=parsed.class_data(class);
                if !class_data.complete {
                    return Err(format!("Class data is incomplete or malformed for {class_name}"));
                }
                let methods=class_data.direct_methods.iter().chain(&class_data.virtual_methods)
                    .filter(|m| parsed.method_name(m.method_idx)==method_name).collect::<Vec<_>>();
                let requested_overload = overload_index.max(0) as usize;
                let Some(method)=methods.get(requested_overload) else {
                    if !methods.is_empty() {
                        return Err(format!("Overload index {requested_overload} is out of range; this method has {} overload(s)", methods.len()));
                    }
                    continue;
                };
                let signature=parsed.method_signature(method);
                let Some(code)=parsed.code(method.code_off) else {
                    return Ok(json!({"ok":true,"dex":dex_name,"class":parsed.class_name(class),"method":signature,
                        "hasCode":false,"instructions":[],"message":"Abstract or native method; no DEX code item."}));
                };
                let (decoded, decode_complete)=dex_ops::decode_with_payload_limit(&code.insns, 200_000, 2 * 1024 * 1024);
                let offset = instruction_offset.max(0) as usize;
                let limit = if instruction_limit <= 0 { 500 } else { (instruction_limit as usize).clamp(1, 5000) };
                let instructions=decoded.iter().skip(offset).take(limit).map(|insn| json!({
                    "offset": format!("{:04x}",insn.offset),
                    "opcode": format!("{:#04x}",insn.opcode),
                    "units": insn.units,
                    "text": parsed.format_insn(insn)
                })).collect::<Vec<_>>();
                return Ok(json!({
                    "ok":true,"dex":dex_name,"class":parsed.class_name(class),"method":signature,
                    "overloadIndex":requested_overload,"overloadCount":methods.len(),
                    "hasCode":true,"registers":code.registers,"inputRegisters":code.ins,
                    "outputRegisters":code.outs,"instructionCount":decoded.len(),
                    "offset":offset,"limit":limit,"nextOffset":if offset.saturating_add(instructions.len()) < decoded.len() { Some(offset.saturating_add(instructions.len())) } else { None },
                    "instructions":instructions,"complete":decode_complete,
                    "tryBlocks":code.tries,"executed":false
                }));
            }
            Err(format!("Class or method not found: {class_name}::{method_name}"))
        })();
        match result { Ok(v)=>v.to_string(), Err(e)=>json!({"ok":false,"error":e,"executed":false}).to_string() }
    };
    #[cfg(not(feature = "upstream-formats"))]
    let payload = serde_json::json!({"ok":false,"error":"Build with upstream-formats to enable Dalvik disassembly"}).to_string();
    to_java_string(&mut env, &payload)
}
