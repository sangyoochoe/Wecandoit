# JNI exports are looked up by their exact class and method names.
-keep class ai.storyteller.craftanything.NativeBridge { *; }
# Enum names are persisted as preference values and must remain stable.
-keep enum ai.storyteller.craftanything.AiProvider { *; }
