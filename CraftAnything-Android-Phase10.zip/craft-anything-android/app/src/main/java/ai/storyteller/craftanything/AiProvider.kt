package ai.storyteller.craftanything

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

enum class AiProvider(val label: String, val defaultModel: String, val defaultBaseUrl: String, val wire: Wire) {
    OPENAI("OpenAI GPT", "gpt-4.1-mini", "https://api.openai.com/v1", Wire.OPENAI),
    ANTHROPIC("Anthropic Claude", "claude-sonnet-4-5", "https://api.anthropic.com", Wire.ANTHROPIC),
    GEMINI("Google Gemini", "gemini-2.5-flash", "https://generativelanguage.googleapis.com/v1beta/openai", Wire.OPENAI),
    OPENROUTER("OpenRouter", "openai/gpt-4.1-mini", "https://openrouter.ai/api/v1", Wire.OPENAI),
    QWEN("Qwen / DashScope", "qwen-plus", "https://dashscope-intl.aliyuncs.com/compatible-mode/v1", Wire.OPENAI),
    OLLAMA("Ollama (로컬)", "qwen2.5:7b", "http://10.0.2.2:11434/v1", Wire.OPENAI),
    CUSTOM("사용자 지정 OpenAI 호환", "", "http://10.0.2.2:1234/v1", Wire.OPENAI);

    enum class Wire { OPENAI, ANTHROPIC }
}

data class AiSettings(
    val provider: AiProvider = AiProvider.OPENAI,
    val model: String = AiProvider.OPENAI.defaultModel,
    val baseUrl: String = AiProvider.OPENAI.defaultBaseUrl,
    val apiKey: String = ""
)

/** AES-GCM encrypted preferences. The AES key is generated and retained by Android Keystore. */
class SecureAiSettings(context: Context) {
    private val prefs = context.getSharedPreferences("ai_provider_settings", Context.MODE_PRIVATE)
    private val alias = "craft_anything_ai_key_v1"

    fun load(): AiSettings {
        val provider = runCatching { AiProvider.valueOf(prefs.getString("provider", "OPENAI")!!) }
            .getOrDefault(AiProvider.OPENAI)
        return AiSettings(
            provider = provider,
            model = prefs.getString("model", provider.defaultModel) ?: provider.defaultModel,
            baseUrl = prefs.getString("baseUrl", provider.defaultBaseUrl) ?: provider.defaultBaseUrl,
            apiKey = decrypt(prefs.getString("apiKey", null))
        )
    }

    fun save(settings: AiSettings) {
        prefs.edit()
            .putString("provider", settings.provider.name)
            .putString("model", settings.model.trim())
            .putString("baseUrl", settings.baseUrl.trim().trimEnd('/'))
            .putString("apiKey", encrypt(settings.apiKey.trim()))
            .apply()
    }

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(
            alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    private fun encrypt(value: String): String {
        if (value.isBlank()) return ""
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return android.util.Base64.encodeToString(cipher.iv + encrypted, android.util.Base64.NO_WRAP)
    }

    private fun decrypt(value: String?): String {
        if (value.isNullOrBlank()) return ""
        return runCatching {
            val raw = android.util.Base64.decode(value, android.util.Base64.NO_WRAP)
            require(raw.size > 12)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            String(cipher.doFinal(raw.copyOfRange(12, raw.size)), Charsets.UTF_8)
        }.getOrDefault("")
    }
}

data class AiMessage(val role: String, val content: String)

class AiChatClient(
    private val settings: AiSettings,
    private val nativeTool: (String, String) -> String,
    private val toolsAvailable: Boolean = true
) {
    companion object {
        private const val MAX_TOOL_ROUNDS = 6
        private const val MAX_RESPONSE_CHARS = 24_000
        private const val MAX_TOOL_OUTPUT_CHARS = 12_000

        // Explicit allowlist: only bounded, read-only Android analysis tools are exposed to the model.
        private val toolNames = listOf(
            "android_package_show", "android_classes_find", "android_class_show",
            "android_class_users_find", "android_resources_read", "android_components_list"
        )
        private val toolDescriptions = mapOf(
            "android_package_show" to "Summarize APK package metadata, manifest, DEX and native libraries.",
            "android_classes_find" to "Search classes in the selected APK or DEX.",
            "android_class_show" to "Show details for one class. Supply class_name.",
            "android_class_users_find" to "Find references to a class. Supply class_name.",
            "android_resources_read" to "Read Android resources. Supply resource_id or query as supported by the tool.",
            "android_components_list" to "List manifest activities, services, receivers and providers."
        )
    }

    /** Fetch the models advertised by the selected provider. This is optional: some compatible
     * servers disable model listing, but chat may still work with a manually entered model id. */
    fun discoverModels(): List<String> {
        validateEndpoint(requireModel = false)
        val endpoint = when (settings.provider.wire) {
            AiProvider.Wire.ANTHROPIC -> anthropicBase() + "/v1/models"
            AiProvider.Wire.OPENAI -> settings.baseUrl.trimEnd('/') + "/models"
        }
        val headers = when (settings.provider.wire) {
            AiProvider.Wire.ANTHROPIC -> mapOf(
                "x-api-key" to settings.apiKey,
                "anthropic-version" to "2023-06-01"
            )
            AiProvider.Wire.OPENAI -> mapOf(
                "Authorization" to if (settings.apiKey.isBlank()) "" else "Bearer ${settings.apiKey}"
            )
        }
        val root = requestGet(endpoint, headers)
        val rows = root.optJSONArray("data") ?: root.optJSONArray("models") ?: JSONArray()
        return (0 until rows.length()).mapNotNull { i ->
            val row = rows.optJSONObject(i) ?: return@mapNotNull null
            (row.optString("id").takeIf { it.isNotBlank() }
                ?: row.optString("name").takeIf { it.isNotBlank() })
        }.distinct().sorted()
    }

    private fun anthropicBase(): String = settings.baseUrl.trimEnd('/').removeSuffix("/v1")

    private fun validateEndpoint(requireModel: Boolean = true) {
        if (requireModel) require(settings.model.isNotBlank()) { "모델 이름을 입력하세요." }
        val parsed = URL(settings.baseUrl)
        require(parsed.userInfo == null && parsed.query == null && parsed.ref == null) {
            "API 주소에 사용자 정보, 쿼리 또는 fragment를 넣을 수 없습니다."
        }
        if (parsed.protocol.equals("http", true)) {
            val host = parsed.host
            val localHost = host.equals("localhost", true) || host.endsWith(".local", true) ||
                runCatching {
                    val address = java.net.InetAddress.getByName(host)
                    address.isLoopbackAddress || address.isSiteLocalAddress || address.isLinkLocalAddress
                }.getOrDefault(false)
            require(localHost && (settings.provider == AiProvider.OLLAMA || settings.provider == AiProvider.CUSTOM)) {
                "HTTP는 localhost 또는 사설망의 Ollama/사용자 지정 서버만 허용합니다. 외부 서버는 HTTPS를 사용하세요."
            }
        } else require(parsed.protocol.equals("https", true)) { "API 주소는 HTTPS를 사용해야 합니다." }
        require(settings.provider == AiProvider.OLLAMA || settings.provider == AiProvider.CUSTOM || settings.apiKey.isNotBlank()) {
            "이 AI 제공자의 API 키를 설정하세요."
        }
    }

    fun ask(userText: String, analysisContext: String): String {
        validateEndpoint()
        val context = analysisContext.take(MAX_RESPONSE_CHARS)
        val toolAvailabilityNote = if (toolsAvailable) {
            "Read-only Rust APK analysis tools are available. Use them when useful."
        } else {
            "No live Rust engine tools are available in this build. Do not claim to have queried the APK; use only supplied evidence and ask for an engine-enabled build if deeper inspection is needed."
        }
        val messages = mutableListOf(
            AiMessage("system", "You are Craft Anything, an evidence-led Android binary analysis assistant. $toolAvailabilityNote Never claim a vulnerability is confirmed without evidence. Never execute the target APK. Clearly distinguish parser facts, hypotheses and unknowns. If no file context is available, ask the user to select an APK or DEX.\n\nCurrent analysis evidence (may be partial):\n$context"),
            AiMessage("user", userText.take(12_000))
        )
        repeat(MAX_TOOL_ROUNDS + 1) { round ->
            val response = if (settings.provider.wire == AiProvider.Wire.ANTHROPIC) {
                callAnthropic(messages)
            } else {
                callOpenAi(messages)
            }
            val calls = response.optJSONArray("toolCalls")
            val answer = response.optString("text")
            if (calls == null || calls.length() == 0) return answer.ifBlank { "모델이 빈 응답을 반환했습니다." }
            if (round >= MAX_TOOL_ROUNDS) return answer.ifBlank { "도구 호출 제한(${MAX_TOOL_ROUNDS}회)에 도달했습니다. 범위를 좁혀 다시 요청하세요." }
            val toolResults = JSONArray()
            for (i in 0 until calls.length()) {
                val call = calls.optJSONObject(i) ?: continue
                val name = call.optString("name")
                val args = call.optJSONObject("arguments") ?: JSONObject()
                if (name !in toolNames) {
                    toolResults.put(JSONObject().put("id", call.optString("id")).put("name", name)
                        .put("content", "Tool not permitted: $name"))
                    continue
                }
                val result = runCatching { nativeTool(name, args.toString()) }
                    .getOrElse { JSONObject().put("ok", false).put("error", it.message ?: "Tool failed").toString() }
                toolResults.put(JSONObject().put("id", call.optString("id")).put("name", name)
                    .put("content", result.take(MAX_TOOL_OUTPUT_CHARS)))
            }
            messages += AiMessage("assistant", JSONObject().put("tool_calls", calls).toString())
            messages += AiMessage("tool", toolResults.toString())
        }
        return "AI 작업이 종료되었습니다."
    }

    private fun callOpenAi(messages: List<AiMessage>): JSONObject {
        val url = settings.baseUrl.trimEnd('/') + "/chat/completions"
        val bodyMessages = JSONArray()
        messages.forEach { msg ->
            if (msg.role == "assistant" && msg.content.startsWith("{")) {
                val stored = runCatching { JSONObject(msg.content) }.getOrNull()
                val normalized = stored?.optJSONArray("tool_calls")
                if (normalized != null && normalized.length() > 0) {
                    val calls = JSONArray()
                    for (i in 0 until normalized.length()) {
                        val call = normalized.optJSONObject(i) ?: continue
                        calls.put(JSONObject().put("id", call.optString("id"))
                            .put("type", "function").put("function", JSONObject()
                                .put("name", call.optString("name"))
                                .put("arguments", (call.optJSONObject("arguments") ?: JSONObject()).toString())))
                    }
                    bodyMessages.put(JSONObject().put("role", "assistant").put("content", JSONObject.NULL).put("tool_calls", calls))
                } else bodyMessages.put(JSONObject().put("role", msg.role).put("content", msg.content))
            } else if (msg.role == "tool") {
                val results = runCatching { JSONArray(msg.content) }.getOrDefault(JSONArray())
                for (i in 0 until results.length()) {
                    val item = results.optJSONObject(i) ?: continue
                    bodyMessages.put(JSONObject().put("role", "tool").put("tool_call_id", item.optString("id"))
                        .put("content", item.optString("content")))
                }
            } else bodyMessages.put(JSONObject().put("role", msg.role).put("content", msg.content))
        }
        val tools = JSONArray()
        (if (toolsAvailable) toolNames else emptyList()).forEach { name ->
            tools.put(JSONObject().put("type", "function").put("function", JSONObject()
                .put("name", name).put("description", toolDescriptions[name]).put("parameters", toolSchema(name))))
        }
        val body = JSONObject().put("model", settings.model).put("messages", bodyMessages)
            .put("tools", tools).put("tool_choice", "auto")
        val root = request(url, body, mapOf("Authorization" to if (settings.apiKey.isBlank()) "" else "Bearer ${settings.apiKey}"))
        val message = root.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
            ?: error("AI 응답에 choices[0].message가 없습니다: ${root.toString().take(1000)}")
        val calls = message.optJSONArray("tool_calls")
        val normalized = JSONArray()
        if (calls != null) for (i in 0 until calls.length()) {
            val item = calls.optJSONObject(i) ?: continue
            val fn = item.optJSONObject("function") ?: continue
            normalized.put(JSONObject().put("id", item.optString("id"))
                .put("name", fn.optString("name"))
                .put("arguments", runCatching { JSONObject(fn.optString("arguments", "{}")) }.getOrDefault(JSONObject())))
        }
        return JSONObject().put("text", message.optString("content")).put("toolCalls", normalized)
    }

    private fun callAnthropic(messages: List<AiMessage>): JSONObject {
        val system = messages.firstOrNull { it.role == "system" }?.content.orEmpty()
        val bodyMessages = JSONArray()
        messages.filter { it.role != "system" }.forEach { msg ->
            if (msg.role == "tool") {
                val results = runCatching { JSONArray(msg.content) }.getOrDefault(JSONArray())
                val content = JSONArray()
                for (i in 0 until results.length()) {
                    val item = results.optJSONObject(i) ?: continue
                    content.put(JSONObject().put("type", "tool_result").put("tool_use_id", item.optString("id"))
                        .put("content", item.optString("content")))
                }
                bodyMessages.put(JSONObject().put("role", "user").put("content", content))
            } else if (msg.role == "assistant" && msg.content.startsWith("{")) {
                // Reconstruct tool_use blocks from the normalized internal representation.
                val raw = runCatching { JSONObject(msg.content).optJSONArray("tool_calls") }.getOrNull()
                val blocks = JSONArray()
                if (raw != null) for (i in 0 until raw.length()) {
                    val item = raw.optJSONObject(i) ?: continue
                    blocks.put(JSONObject().put("type", "tool_use").put("id", item.optString("id"))
                        .put("name", item.optString("name")).put("input", item.optJSONObject("arguments") ?: JSONObject()))
                }
                bodyMessages.put(JSONObject().put("role", "assistant").put("content", blocks))
            } else {
                bodyMessages.put(JSONObject().put("role", msg.role).put("content", msg.content))
            }
        }
        val tools = JSONArray()
        (if (toolsAvailable) toolNames else emptyList()).forEach { name ->
            tools.put(JSONObject().put("name", name).put("description", toolDescriptions[name])
                .put("input_schema", toolSchema(name)))
        }
        val body = JSONObject().put("model", settings.model).put("max_tokens", 4096)
            .put("system", system).put("messages", bodyMessages).put("tools", tools)
        val root = request(anthropicBase() + "/v1/messages", body, mapOf(
            "x-api-key" to settings.apiKey, "anthropic-version" to "2023-06-01"
        ))
        val content = root.optJSONArray("content") ?: JSONArray()
        val normalized = JSONArray()
        val text = StringBuilder()
        for (i in 0 until content.length()) {
            val block = content.optJSONObject(i) ?: continue
            when (block.optString("type")) {
                "text" -> text.append(block.optString("text"))
                "tool_use" -> normalized.put(JSONObject().put("id", block.optString("id"))
                    .put("name", block.optString("name")).put("arguments", block.optJSONObject("input") ?: JSONObject()))
            }
        }
        return JSONObject().put("text", text.toString()).put("toolCalls", normalized)
    }

    private fun toolSchema(name: String): JSONObject {
        fun field(type: String, description: String) = JSONObject().put("type", type).put("description", description)
        val properties = JSONObject()
        val required = JSONArray()
        when (name) {
            "android_classes_find" -> {
                properties.put("query", field("string", "Class-name substring; empty lists classes."))
                properties.put("offset", field("integer", "Zero-based page offset."))
                properties.put("limit", field("integer", "Rows per page, 1 to 5000."))
            }
            "android_class_show" -> {
                properties.put("class_name", field("string", "Class name, e.g. com.example.Main or Lcom/example/Main;"))
                required.put("class_name")
            }
            "android_class_users_find" -> {
                properties.put("class_name", field("string", "Referenced class name."))
                properties.put("method_name", field("string", "Optional method name filter."))
                properties.put("offset", field("integer", "Zero-based page offset."))
                properties.put("limit", field("integer", "Rows per page, 1 to 5000."))
                required.put("class_name")
            }
            "android_resources_read" -> {
                properties.put("with_strings", field("boolean", "Include string resources."))
                properties.put("locale", field("string", "Optional locale, e.g. en or default."))
                properties.put("type_name", field("string", "Optional resource type such as string, color or style."))
                properties.put("offset", field("integer", "Zero-based page offset."))
                properties.put("limit", field("integer", "Rows per page, 1 to 5000."))
            }
            "android_components_list" -> {
                properties.put("kind", field("string", "Optional activity, activity-alias, service, receiver or provider."))
                properties.put("reachable_only", field("boolean", "Only components other apps can reach."))
                properties.put("offset", field("integer", "Zero-based page offset."))
                properties.put("limit", field("integer", "Rows per page, 1 to 5000."))
            }
            "android_package_show" -> properties.put("include_manifest_xml", field("boolean", "Include decoded manifest XML."))
        }
        return JSONObject().put("type", "object").put("properties", properties)
            .put("required", required).put("additionalProperties", false)
    }

    private fun requestGet(urlText: String, headers: Map<String, String>): JSONObject {
        val connection = (URL(urlText).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            instanceFollowRedirects = false
            connectTimeout = 15_000
            readTimeout = 30_000
            setRequestProperty("Accept", "application/json")
            headers.forEach { (key, value) -> if (value.isNotBlank()) setRequestProperty(key, value) }
        }
        try {
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { reader ->
                val out = StringBuilder()
                val buffer = CharArray(8192)
                while (true) {
                    val n = reader.read(buffer)
                    if (n < 0) break
                    require(out.length + n <= 2 * 1024 * 1024) { "모델 목록 응답이 2 MiB 제한을 초과했습니다." }
                    out.append(buffer, 0, n)
                }
                out.toString()
            }.orEmpty()
            if (status !in 200..299) {
                val detail = runCatching { JSONObject(text).optJSONObject("error")?.optString("message") }.getOrNull()
                    ?.takeIf { it.isNotBlank() } ?: text.take(1000)
                error("모델 목록 조회 실패 HTTP $status: $detail")
            }
            return JSONObject(text)
        } finally {
            connection.disconnect()
        }
    }

    private fun request(urlText: String, body: JSONObject, headers: Map<String, String>): JSONObject {
        val connection = (URL(urlText).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            instanceFollowRedirects = false
            connectTimeout = 20_000
            readTimeout = 120_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            headers.forEach { (key, value) -> if (value.isNotBlank()) setRequestProperty(key, value) }
        }
        try {
            val payload = body.toString().toByteArray(Charsets.UTF_8)
            require(payload.size <= 2 * 1024 * 1024) { "AI 요청 본문이 2 MiB 제한을 초과했습니다." }
            connection.outputStream.use { it.write(payload) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { reader ->
                val out = StringBuilder()
                val buffer = CharArray(8192)
                while (true) {
                    val n = reader.read(buffer)
                    if (n < 0) break
                    require(out.length + n <= 2 * 1024 * 1024) { "AI 응답이 2 MiB 제한을 초과했습니다." }
                    out.append(buffer, 0, n)
                }
                out.toString()
            }.orEmpty()
            if (status !in 200..299) {
                val detail = runCatching { JSONObject(text).optJSONObject("error")?.optString("message") }.getOrNull()
                    ?.takeIf { it.isNotBlank() } ?: text.take(1200)
                error("AI 서버 오류 HTTP $status: $detail")
            }
            return JSONObject(text)
        } finally {
            connection.disconnect()
        }
    }
}
