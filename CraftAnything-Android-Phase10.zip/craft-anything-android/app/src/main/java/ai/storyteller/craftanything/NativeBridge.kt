package ai.storyteller.craftanything

object NativeBridge {
    init {
        System.loadLibrary("craft_anything_android_bridge")
    }

    external fun nativeStatus(): String
    external fun nativeToolCatalog(): String
    external fun nativeInspectBytes(fileName: String, bytes: ByteArray): String
    external fun nativeAnalyzeAndroid(fileName: String, bytes: ByteArray): String
    external fun nativeDisassembleAndroidMethod(
        fileName: String, bytes: ByteArray, className: String, methodName: String,
        overloadIndex: Int, instructionOffset: Int, instructionLimit: Int
    ): String
    external fun nativeRunAndroidTool(
        fileName: String, bytes: ByteArray, toolId: String, paramsJson: String, cacheDir: String
    ): String
}
