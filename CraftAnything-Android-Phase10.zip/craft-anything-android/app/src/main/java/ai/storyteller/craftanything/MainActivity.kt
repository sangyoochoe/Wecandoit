package ai.storyteller.craftanything

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import org.json.JSONObject

private const val MAX_FILE_BYTES = 64 * 1024 * 1024

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bridgeStatus = runCatching { NativeBridge.nativeStatus() }
            .getOrElse { "Rust 라이브러리가 아직 설치되지 않았습니다. native/build-android.sh 실행 필요." }
        val catalogJson = runCatching { NativeBridge.nativeToolCatalog() }
            .getOrElse { "{\"connected\":false,\"reason\":\"JNI library unavailable\"}" }
        setContent { CraftAnythingApp(bridgeStatus, catalogJson) }
    }

    private suspend fun readSelectedBytes(uri: Uri): Pair<String, ByteArray> = withContext(Dispatchers.IO) {
        val metadata = contentResolver.query(
            uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                val name = if (nameIndex >= 0) cursor.getString(nameIndex) else null
                val size = if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) cursor.getLong(sizeIndex) else -1L
                name to size
            } else null
        }
        val displayName = metadata?.first
        val expectedSize = metadata?.second ?: -1L
        require(expectedSize <= MAX_FILE_BYTES || expectedSize < 0) {
            "파일은 64 MiB 이하만 분석할 수 있습니다."
        }
        val bytes = contentResolver.openInputStream(uri)?.use { input ->
            if (expectedSize in 0..MAX_FILE_BYTES.toLong()) {
                // Pre-size known documents to avoid ByteArrayOutputStream's extra full-size copy.
                val target = ByteArray(expectedSize.toInt())
                var offset = 0
                while (offset < target.size) {
                    val count = input.read(target, offset, minOf(64 * 1024, target.size - offset))
                    if (count < 0) break
                    offset += count
                }
                require(offset == target.size && input.read() == -1) {
                    "파일 크기가 메타데이터와 다릅니다. 다시 선택해 주세요."
                }
                target
            } else {
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(64 * 1024)
                var total = 0
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    require(total <= MAX_FILE_BYTES) { "파일은 64 MiB 이하만 분석할 수 있습니다." }
                    out.write(buffer, 0, count)
                }
                out.toByteArray()
            }
        } ?: error("파일을 열 수 없습니다.")
        val name = displayName?.takeIf { it.isNotBlank() } ?: uri.lastPathSegment?.substringAfterLast('/') ?: "selected-file"
        name to bytes
    }

    fun askAi(
        uri: Uri?, settings: AiSettings, question: String, analysisContext: String,
        toolsAvailable: Boolean, onResult: (String) -> Unit
    ) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    // Do not load a 64 MiB document into memory for a text-only AI request.
                    val file = if (toolsAvailable && uri != null) readSelectedBytes(uri) else null
                    AiChatClient(settings, { toolId, params ->
                        val (name, bytes) = file ?: error("실행 가능한 Rust 분석 도구가 없습니다.")
                        require(bytes.isNotEmpty()) { "도구를 실행하려면 먼저 APK 또는 DEX 파일을 선택하세요." }
                        NativeBridge.nativeRunAndroidTool(name, bytes, toolId, params, cacheDir.absolutePath)
                    }, toolsAvailable && file != null).ask(question, analysisContext)
                }.getOrElse { "AI 요청 실패: ${it.message ?: "알 수 없는 오류"}" }
            }
            onResult(result)
        }
    }

    fun discoverAiModels(settings: AiSettings, onResult: (Result<List<String>>) -> Unit) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching { AiChatClient(settings, { _, _ -> error("모델 검색 중 도구 호출은 지원하지 않습니다.") }, false).discoverModels() }
            }
            onResult(result)
        }
    }

    fun inspect(uri: Uri, onResult: (String) -> Unit) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val (name, bytes) = readSelectedBytes(uri)
                    val quick = NativeBridge.nativeInspectBytes(name, bytes)
                    val deep = NativeBridge.nativeAnalyzeAndroid(name, bytes)
                    """{"quickCheck":$quick,"upstreamAnalysis":$deep}"""
                }.getOrElse { JSONObject().put("ok", false).put("error", it.message ?: "분석 실패").toString() }
            }
            onResult(result)
        }
    }

    fun disassemble(
        uri: Uri, className: String, methodName: String, overloadIndex: Int,
        instructionOffset: Int, instructionLimit: Int, onResult: (String) -> Unit
    ) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val (name, bytes) = readSelectedBytes(uri)
                    NativeBridge.nativeDisassembleAndroidMethod(
                        name, bytes, className, methodName, overloadIndex, instructionOffset, instructionLimit
                    )
                }.getOrElse { JSONObject().put("ok", false).put("error", it.message ?: "디스어셈블 실패").toString() }
            }
            onResult(result)
        }
    }

    fun runAndroidTool(uri: Uri, toolId: String, params: String, onResult: (String) -> Unit) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val (name, bytes) = readSelectedBytes(uri)
                    NativeBridge.nativeRunAndroidTool(name, bytes, toolId, params, cacheDir.absolutePath)
                }.getOrElse { JSONObject().put("ok", false).put("error", it.message ?: "엔진 도구 실행 실패").toString() }
            }
            onResult(result)
        }
    }
}


@Composable
private fun AnalysisResultView(raw: String) {
    val root = remember(raw) { runCatching { JSONObject(raw) }.getOrNull() }
    if (root == null) {
        Text(raw, style = MaterialTheme.typography.bodySmall)
        return
    }
    val upstream = root.optJSONObject("upstreamAnalysis")
    if (upstream == null) {
        Text(root.optString("error", raw), style = MaterialTheme.typography.bodySmall)
        return
    }
    if (!upstream.optBoolean("ok", false)) {
        Text(upstream.optString("error", "분석 결과를 읽을 수 없습니다."), style = MaterialTheme.typography.bodySmall)
        return
    }
    val manifest = upstream.optJSONObject("manifest")
    val resources = upstream.optJSONObject("resources")
    val dexFiles = upstream.optJSONArray("dexFiles")
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("${upstream.optString("format", "파일")} · ${upstream.optString("parser", "parser")}",
            style = MaterialTheme.typography.labelMedium)
        if (manifest != null) {
            HorizontalDivider()
            Text("앱 매니페스트", style = MaterialTheme.typography.titleMedium)
            ResultLine("패키지", manifest.optString("package", "확인 불가"))
            ResultLine("버전", listOf(
                manifest.optString("versionName", "").takeIf { it.isNotBlank() },
                manifest.optString("versionCode", "").takeIf { it.isNotBlank() }?.let { "($it)" }
            ).filterNotNull().joinToString(" ").ifBlank { "정보 없음" })
            ResultLine("SDK", "min ${manifest.optString("minSdk", "-")} · target ${manifest.optString("targetSdk", "-")} · max ${manifest.optString("maxSdk", "-")}")
            val permissions = manifest.optJSONArray("permissions")
            Text("요청 권한 (${permissions?.length() ?: 0})", style = MaterialTheme.typography.labelLarge)
            permissions?.let { arr ->
                for (i in 0 until minOf(arr.length(), 30)) {
                    Text("• ${arr.optString(i)}", style = MaterialTheme.typography.bodySmall)
                }
                if (arr.length() > 30) Text("외 ${arr.length() - 30}개", style = MaterialTheme.typography.bodySmall)
            }
            val components = manifest.optJSONArray("components")
            Text("컴포넌트 (${manifest.optInt("componentCount", components?.length() ?: 0)})",
                style = MaterialTheme.typography.labelLarge)
            components?.let { arr ->
                for (i in 0 until minOf(arr.length(), 30)) {
                    val item = arr.optJSONObject(i) ?: continue
                    val exported = if (item.isNull("exported_attribute")) "미지정" else item.optString("exported")
                    Text("• ${item.optString("kind")} · ${item.optString("name")} · exported=$exported",
                        style = MaterialTheme.typography.bodySmall)
                }
                if (arr.length() > 30) Text("외 ${arr.length() - 30}개", style = MaterialTheme.typography.bodySmall)
            }
        } else if (upstream.optBoolean("hasAndroidManifest")) {
            Text(upstream.optString("manifestError", "매니페스트 해석 실패"), style = MaterialTheme.typography.bodySmall)
        }
        if (resources != null) {
            HorizontalDivider()
            Text("리소스 테이블", style = MaterialTheme.typography.titleMedium)
            ResultLine("패키지", resources.optInt("packageCount").toString())
            ResultLine("리소스 항목", resources.optInt("entryCount").toString())
            val packages = resources.optJSONArray("packages")
            packages?.let { arr ->
                for (i in 0 until minOf(arr.length(), 20)) {
                    val item = arr.optJSONObject(i) ?: continue
                    Text("• ${item.optString("name")} · type ${item.optInt("types").let { item.optJSONArray("types")?.length() ?: it }}",
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        } else if (upstream.optBoolean("hasResourcesTable")) {
            Text(upstream.optString("resourcesError", "리소스 테이블 해석 실패"), style = MaterialTheme.typography.bodySmall)
        }
        if (dexFiles != null) {
            HorizontalDivider()
            Text("DEX 파일 (${dexFiles.length()})", style = MaterialTheme.typography.titleMedium)
            for (i in 0 until dexFiles.length()) {
                val dex = dexFiles.optJSONObject(i) ?: continue
                Text("${dex.optString("entry")} · DEX ${dex.optString("dexVersion")} · 클래스 ${dex.optInt("classCount")} · 메서드 ${dex.optInt("methodCount")}",
                    style = MaterialTheme.typography.bodySmall)
                val methods = dex.optJSONArray("methodPreview")
                methods?.let { arr ->
                    Text("메서드 미리보기 (${arr.length()})", style = MaterialTheme.typography.labelLarge)
                    for (j in 0 until minOf(arr.length(), 20)) {
                        val method = arr.optJSONObject(j) ?: continue
                        Text("• ${method.optString("signature")} · code units ${method.optInt("codeUnits")}",
                            style = MaterialTheme.typography.bodySmall)
                    }
                    if (arr.length() > 20) Text("외 ${arr.length() - 20}개", style = MaterialTheme.typography.bodySmall)
                }
                val classes = dex.optJSONArray("classes")
                classes?.let { arr ->
                    for (j in 0 until minOf(arr.length(), 8)) {
                        Text("  ${arr.optString(j)}", style = MaterialTheme.typography.bodySmall)
                    }
                    if (arr.length() > 8) Text("  외 ${arr.length() - 8}개", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        ResultLine("ZIP 항목", upstream.optInt("entryCount").toString())
        Text("실행 여부: 실행하지 않음", style = MaterialTheme.typography.labelMedium)
        Text("원본 JSON은 화면 요약으로 표시되며, 일부 항목은 안전을 위해 개수 제한이 적용됩니다.",
            style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ResultLine(label: String, value: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("$label:", style = MaterialTheme.typography.labelMedium)
        Text(value, style = MaterialTheme.typography.bodySmall)
    }
}


@Composable
private fun JsonResultCard(title: String, raw: String) {
    val obj = remember(raw) { runCatching { JSONObject(raw) }.getOrNull() }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        if (obj == null) {
            Text(raw, style = MaterialTheme.typography.bodySmall)
        } else if (!obj.optBoolean("ok", false)) {
            Text(obj.optString("error", "실패"), style = MaterialTheme.typography.bodySmall)
        } else {
            Text(obj.optString("method", obj.optString("tool", "완료")), style = MaterialTheme.typography.labelLarge)
            Text("명령/항목: ${obj.optInt("instructionCount", obj.optInt("count", 0))}",
                style = MaterialTheme.typography.bodySmall)
            val instructions = obj.optJSONArray("instructions")
            instructions?.let { arr ->
                for (i in 0 until minOf(arr.length(), 120)) {
                    val row = arr.optJSONObject(i) ?: continue
                    Text("${row.optString("offset")}: ${row.optString("text")}",
                        style = MaterialTheme.typography.bodySmall)
                }
                if (arr.length() > 300) Text("화면에는 앞 120개만 표시 (전체 ${arr.length()}개)", style = MaterialTheme.typography.bodySmall)
            }
            val result = obj.optJSONObject("result")
            if (result != null) {
                Text(result.toString(2).take(12000), style = MaterialTheme.typography.bodySmall)
            }
            if (obj.has("complete")) Text("디코딩 완전성: ${obj.optBoolean("complete")}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

private enum class MobileTab(val title: String, val symbol: String) {
    ANALYZE("홈", "⌂"), TOOLS("분석 도구", "⌘"), AI("AI", "✦"), SETTINGS("설정", "⚙")
}

private val CraftBackground = Color(0xFF121316)
private val CraftSurface = Color(0xFF1B1C1F)
private val CraftSurfaceVariant = Color(0xFF25262A)
private val CraftAccent = Color(0xFF74AAFF)
private val CraftMint = Color(0xFF69D8BD)

private val CraftColorScheme = darkColorScheme(
    primary = CraftAccent,
    onPrimary = Color(0xFF101014),
    secondary = CraftMint,
    onSecondary = Color(0xFF06251F),
    background = CraftBackground,
    onBackground = Color(0xFFE9EAF2),
    surface = CraftSurface,
    onSurface = Color(0xFFE9EAF2),
    surfaceVariant = CraftSurfaceVariant,
    onSurfaceVariant = Color(0xFFB5B9CA),
    outline = Color(0xFF41485B),
    error = Color(0xFFFF7D8B)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CraftAnythingApp(bridgeStatus: String, catalogJson: String) {
    val activity = androidx.compose.ui.platform.LocalContext.current as MainActivity
    var activeTab by remember { mutableStateOf(MobileTab.ANALYZE) }
    var advancedMode by remember { mutableStateOf(false) }
    var selectedFile by remember { mutableStateOf<Uri?>(null) }
    var fileLabel by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("분석할 APK 또는 DEX 파일을 선택하세요.") }
    var analysisResult by remember { mutableStateOf("") }
    var analysisContext by remember { mutableStateOf("") }
    var isAnalyzing by remember { mutableStateOf(false) }

    var className by remember { mutableStateOf("") }
    var methodName by remember { mutableStateOf("") }
    var overloadIndex by remember { mutableStateOf("0") }
    var instructionOffset by remember { mutableStateOf("0") }
    var instructionLimit by remember { mutableStateOf("300") }
    var methodResult by remember { mutableStateOf("") }
    var toolId by remember { mutableStateOf("android_package_show") }
    var toolParams by remember { mutableStateOf("{}") }
    var toolResult by remember { mutableStateOf("") }
    var isToolRunning by remember { mutableStateOf(false) }

    var aiQuestion by remember { mutableStateOf("이 APK의 구조와 주요 보안 위험 후보를 근거와 불확실성을 구분해 분석해줘.") }
    var aiAnswer by remember { mutableStateOf("") }
    var isAiRunning by remember { mutableStateOf(false) }
    var aiSettings by remember { mutableStateOf(SecureAiSettings(activity).load()) }
    var providerMenu by remember { mutableStateOf(false) }
    var discoveredModels by remember { mutableStateOf<List<String>>(emptyList()) }
    var modelMenu by remember { mutableStateOf(false) }
    var modelDiscoveryStatus by remember { mutableStateOf("") }
    var discoveringModels by remember { mutableStateOf(false) }
    val nativeEngineAvailable = remember(catalogJson) {
        runCatching { JSONObject(catalogJson).optBoolean("connected", false) }.getOrDefault(false)
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                activity.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            selectedFile = uri
            fileLabel = uri.lastPathSegment?.substringAfterLast('/') ?: "선택한 파일"
            status = "파일이 선택되었습니다. 분석을 시작하세요."
            analysisResult = ""
            analysisContext = ""
            methodResult = ""
            toolResult = ""
            aiAnswer = ""
        }
    }

    MaterialTheme(
        colorScheme = CraftColorScheme,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(6.dp),
            small = RoundedCornerShape(10.dp),
            medium = RoundedCornerShape(14.dp),
            large = RoundedCornerShape(18.dp),
            extraLarge = RoundedCornerShape(22.dp)
        )
    ) {
        Scaffold(
            containerColor = CraftBackground,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = CraftBackground,
                        titleContentColor = MaterialTheme.colorScheme.onBackground,
                        actionIconContentColor = CraftAccent
                    ),
                    title = {
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("CRAFT", style = MaterialTheme.typography.labelMedium,
                                    color = CraftAccent)
                                Text("ANYTHING", style = MaterialTheme.typography.titleMedium)
                                Surface(shape = RoundedCornerShape(50), color = CraftSurfaceVariant) {
                                    Text("ANDROID", Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Text(
                                selectedFile?.let { fileLabel.ifBlank { "파일 선택됨" } } ?: "모바일 바이너리 분석 워크스페이스",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    },
                    actions = {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            TextButton(onClick = {
                                advancedMode = false
                                if (activeTab == MobileTab.TOOLS) activeTab = MobileTab.ANALYZE
                            }) {
                                Text("간편", color = if (!advancedMode) CraftAccent else MaterialTheme.colorScheme.onSurfaceVariant,
                                    style = MaterialTheme.typography.labelMedium)
                            }
                            TextButton(onClick = { advancedMode = true }) {
                                Text("전문가", color = if (advancedMode) CraftAccent else MaterialTheme.colorScheme.onSurfaceVariant,
                                    style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = Color(0xFF101014),
                    contentColor = MaterialTheme.colorScheme.onSurface,
                    tonalElevation = 0.dp
                ) {
                    (if (advancedMode) MobileTab.entries else listOf(MobileTab.ANALYZE, MobileTab.AI, MobileTab.SETTINGS)).forEach { tab ->
                        NavigationBarItem(
                            selected = activeTab == tab,
                            onClick = { activeTab = tab },
                            icon = {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (activeTab == tab) CraftAccent.copy(alpha = 0.18f) else Color.Transparent
                                ) {
                                    Text(tab.symbol, Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                                        style = MaterialTheme.typography.titleLarge,
                                        color = if (activeTab == tab) CraftAccent else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            },
                            label = { Text(tab.title, style = MaterialTheme.typography.labelSmall) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = CraftAccent,
                                selectedTextColor = CraftAccent,
                                indicatorColor = Color.Transparent,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (activeTab) {
                MobileTab.ANALYZE -> LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = CraftSurface)) {
                            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("WORKSPACE / 01", style = MaterialTheme.typography.labelSmall, color = CraftAccent)
                                Text("무엇을 분석할까요?", style = MaterialTheme.typography.headlineSmall)
                                Text("APK · DEX · ZIP · ELF · PE", style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.secondary)
                                Text("파일은 기기에서 읽어 Rust 파서로 분석합니다. 선택한 파일 자체를 실행하지 않습니다.",
                                    style = MaterialTheme.typography.bodySmall)
                                OutlinedButton(
                                    onClick = { picker.launch(arrayOf("*/*")) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CraftAccent)
                                ) { Text(if (selectedFile == null) "＋  분석할 파일 선택" else "파일 변경") }
                                if (selectedFile != null) {
                                    Text(fileLabel, style = MaterialTheme.typography.labelLarge, maxLines = 2)
                                    Button(
                                        shape = RoundedCornerShape(16.dp),
                                        onClick = {
                                            val uri = selectedFile ?: return@Button
                                            isAnalyzing = true
                                            status = "파일 읽기 및 분석 중…"
                                            activity.inspect(uri) { result ->
                                                analysisResult = result
                                                analysisContext = result
                                                status = "분석 완료"
                                                isAnalyzing = false
                                            }
                                        },
                                        enabled = !isAnalyzing,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        if (isAnalyzing) {
                                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                            Spacer(Modifier.width(8.dp))
                                        }
                                        Text(if (isAnalyzing) "분석 중…" else "기기에서 분석하기")
                                    }
                                }
                            }
                        }
                    }
                    item {
                        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = CraftSurface)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("ANALYSIS / OVERVIEW", style = MaterialTheme.typography.labelMedium,
                                        color = CraftAccent)
                                    if (analysisResult.isNotBlank()) Text("완료", color = MaterialTheme.colorScheme.primary,
                                        style = MaterialTheme.typography.labelMedium)
                                }
                                if (analysisResult.isBlank()) {
                                    Text(status, style = MaterialTheme.typography.titleMedium)
                                    Text("파일을 선택하고 분석을 실행하면 매니페스트, 권한, 컴포넌트, DEX 및 리소스 정보가 여기에 표시됩니다.",
                                        style = MaterialTheme.typography.bodySmall)
                                } else {
                                    AnalysisResultView(analysisResult)
                                }
                            }
                        }
                    }
                    item {
                        OutlinedCard(onClick = { activeTab = MobileTab.TOOLS }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) {
                                    Text("상세 도구", style = MaterialTheme.typography.titleMedium)
                                    Text("클래스 검색, 메서드 디스어셈블 및 Rust 도구", style = MaterialTheme.typography.bodySmall)
                                }
                                Text("열기  ›", color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                    item {
                        OutlinedCard(onClick = { activeTab = MobileTab.AI }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) {
                                    Text("AI 분석", style = MaterialTheme.typography.titleMedium)
                                    Text("분석 결과를 바탕으로 질문하고 근거를 확인하세요.", style = MaterialTheme.typography.bodySmall)
                                }
                                Text("열기  ›", color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }

                MobileTab.TOOLS -> LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 28.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = CraftSurface)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("DEX / DISASSEMBLY", style = MaterialTheme.typography.labelSmall, color = CraftAccent)
                                Text("메서드 디스어셈블", style = MaterialTheme.typography.titleLarge)
                                Text("DEX 메서드의 Dalvik 명령어를 페이지 단위로 확인합니다.", style = MaterialTheme.typography.bodySmall)
                                OutlinedTextField(className, { className = it }, Modifier.fillMaxWidth(),
                                    singleLine = true, label = { Text("클래스명") })
                                OutlinedTextField(methodName, { methodName = it }, Modifier.fillMaxWidth(),
                                    singleLine = true, label = { Text("메서드명") })
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(overloadIndex, { overloadIndex = it.filter(Char::isDigit).take(4) },
                                        Modifier.weight(1f), singleLine = true, label = { Text("오버로드") })
                                    OutlinedTextField(instructionOffset, { instructionOffset = it.filter(Char::isDigit).take(8) },
                                        Modifier.weight(1f), singleLine = true, label = { Text("Offset") })
                                    OutlinedTextField(instructionLimit, { instructionLimit = it.filter(Char::isDigit).take(4) },
                                        Modifier.weight(1f), singleLine = true, label = { Text("개수") })
                                }
                                Button(
                                    onClick = {
                                        val uri = selectedFile ?: return@Button
                                        isToolRunning = true
                                        methodResult = ""
                                        activity.disassemble(uri, className, methodName,
                                            overloadIndex.toIntOrNull() ?: 0,
                                            instructionOffset.toIntOrNull() ?: 0,
                                            (instructionLimit.toIntOrNull() ?: 300).coerceIn(1, 5000)
                                        ) { methodResult = it; isToolRunning = false }
                                    },
                                    enabled = selectedFile != null && className.isNotBlank() && methodName.isNotBlank() && !isToolRunning,
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text(if (isToolRunning) "처리 중…" else "명령어 보기") }
                                if (methodResult.isNotBlank()) JsonResultCard("디스어셈블 결과", methodResult)
                            }
                        }
                    }
                    item {
                        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = CraftSurface)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("ENGINE / TOOLS", style = MaterialTheme.typography.labelSmall, color = CraftAccent)
                                Text("Rust 엔진 도구", style = MaterialTheme.typography.titleLarge)
                                Text(if (nativeEngineAvailable) "엔진 연결됨" else "현재 빌드에서 원본 엔진 실행은 비활성화됨",
                                    color = if (nativeEngineAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall)
                                OutlinedTextField(toolId, { toolId = it.trim().take(64) }, Modifier.fillMaxWidth(),
                                    singleLine = true, label = { Text("도구 ID") })
                                OutlinedTextField(toolParams, { toolParams = it }, Modifier.fillMaxWidth(),
                                    minLines = 2, label = { Text("파라미터 JSON") })
                                Button(
                                    onClick = {
                                        val uri = selectedFile ?: return@Button
                                        isToolRunning = true
                                        activity.runAndroidTool(uri, toolId, toolParams) { toolResult = it; isToolRunning = false }
                                    },
                                    enabled = selectedFile != null && nativeEngineAvailable && !isToolRunning,
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text(if (isToolRunning) "실행 중…" else "도구 실행") }
                                if (toolResult.isNotBlank()) JsonResultCard("도구 결과", toolResult)
                            }
                        }
                    }
                }

                MobileTab.AI -> LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 28.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = CraftSurface)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("ASSISTANT / 01", style = MaterialTheme.typography.labelSmall, color = CraftAccent)
                                Text("AI 분석 도우미", style = MaterialTheme.typography.headlineSmall)
                                Text("질문과 분석 요약이 선택한 AI 제공자에게 전송됩니다. 원본 파일 바이트 전체를 AI 서버로 업로드하지 않습니다.",
                                    style = MaterialTheme.typography.bodySmall)
                                if (!nativeEngineAvailable) {
                                    Text("Rust 도구 연결은 아직 비활성화되어 있어, AI는 현재 제공된 분석 결과만 참조할 수 있습니다.",
                                        color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                                }
                                OutlinedTextField(aiQuestion, { aiQuestion = it }, Modifier.fillMaxWidth(),
                                    minLines = 4, label = { Text("무엇을 분석할까요?") })
                                Button(
                                    onClick = {
                                        SecureAiSettings(activity).save(aiSettings)
                                        isAiRunning = true
                                        aiAnswer = ""
                                        activity.askAi(selectedFile, aiSettings, aiQuestion, analysisContext, nativeEngineAvailable) {
                                            aiAnswer = it
                                            isAiRunning = false
                                        }
                                    },
                                    enabled = aiQuestion.isNotBlank() && !isAiRunning,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    if (isAiRunning) {
                                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                        Spacer(Modifier.width(8.dp))
                                    }
                                    Text(if (isAiRunning) "AI가 분석 중…" else "AI에게 질문하기")
                                }
                            }
                        }
                    }
                    if (aiAnswer.isNotBlank()) {
                        item {
                            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = CraftSurface)) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("RESPONSE", style = MaterialTheme.typography.labelMedium, color = CraftMint)
                                    Text("AI 답변", style = MaterialTheme.typography.titleLarge)
                                    Text(aiAnswer, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                    item {
                        TextButton(onClick = { activeTab = MobileTab.SETTINGS }) {
                            Text("AI 제공자와 모델 설정  ›")
                        }
                    }
                }

                MobileTab.SETTINGS -> LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 28.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = CraftSurface)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("PREFERENCES / AI", style = MaterialTheme.typography.labelSmall, color = CraftAccent)
                                Text("AI 제공자", style = MaterialTheme.typography.titleLarge)
                                ExposedDropdownMenuBox(
                                    expanded = providerMenu,
                                    onExpandedChange = { providerMenu = !providerMenu }
                                ) {
                                    OutlinedTextField(
                                        value = aiSettings.provider.label, onValueChange = {}, readOnly = true,
                                        modifier = Modifier.menuAnchor().fillMaxWidth(), label = { Text("제공자") }
                                    )
                                    ExposedDropdownMenu(providerMenu, { providerMenu = false }) {
                                        AiProvider.entries.forEach { provider ->
                                            DropdownMenuItem(text = { Text(provider.label) }, onClick = {
                                                aiSettings = aiSettings.copy(
                                                    provider = provider,
                                                    model = provider.defaultModel,
                                                    baseUrl = provider.defaultBaseUrl,
                                                    apiKey = if (provider == aiSettings.provider) aiSettings.apiKey else ""
                                                )
                                                providerMenu = false
                                            })
                                        }
                                    }
                                }
                                OutlinedTextField(aiSettings.model, { aiSettings = aiSettings.copy(model = it) },
                                    Modifier.fillMaxWidth(), singleLine = true, label = { Text("모델 ID") })
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            discoveringModels = true
                                            modelDiscoveryStatus = "모델 목록 조회 중…"
                                            activity.discoverAiModels(aiSettings) { result ->
                                                discoveringModels = false
                                                result.onSuccess { models ->
                                                    discoveredModels = models
                                                    modelDiscoveryStatus = if (models.isEmpty()) "모델 목록을 제공하지 않습니다. ID를 직접 입력하세요." else "${models.size}개 모델을 찾았습니다."
                                                    if (models.size == 1) aiSettings = aiSettings.copy(model = models.first())
                                                }.onFailure { modelDiscoveryStatus = it.message ?: "모델 조회 실패" }
                                            }
                                        },
                                        enabled = !discoveringModels, modifier = Modifier.weight(1f)
                                    ) { Text(if (discoveringModels) "조회 중…" else "모델 조회") }
                                    OutlinedButton(
                                        onClick = { modelMenu = true }, enabled = discoveredModels.isNotEmpty(),
                                        modifier = Modifier.weight(1f)
                                    ) { Text("모델 선택") }
                                    DropdownMenu(modelMenu, { modelMenu = false }) {
                                        discoveredModels.take(80).forEach { model ->
                                            DropdownMenuItem(text = { Text(model, maxLines = 1) }, onClick = {
                                                aiSettings = aiSettings.copy(model = model)
                                                modelMenu = false
                                            })
                                        }
                                    }
                                }
                                if (modelDiscoveryStatus.isNotBlank()) Text(modelDiscoveryStatus, style = MaterialTheme.typography.bodySmall)
                                OutlinedTextField(aiSettings.baseUrl, { aiSettings = aiSettings.copy(baseUrl = it) },
                                    Modifier.fillMaxWidth(), singleLine = true, label = { Text("API 주소") })
                                OutlinedTextField(aiSettings.apiKey, { aiSettings = aiSettings.copy(apiKey = it) },
                                    Modifier.fillMaxWidth(), singleLine = true,
                                    visualTransformation = PasswordVisualTransformation(),
                                    label = { Text(if (aiSettings.provider == AiProvider.OLLAMA) "API 키 (선택)" else "API 키") })
                                Button(
                                    onClick = {
                                        SecureAiSettings(activity).save(aiSettings)
                                        status = "AI 설정을 안전하게 저장했습니다."
                                    }, modifier = Modifier.fillMaxWidth()
                                ) { Text("설정 저장") }
                            }
                        }
                    }
                    item {
                        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = CraftSurface)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("앱 상태", style = MaterialTheme.typography.titleLarge)
                                Text(bridgeStatus, style = MaterialTheme.typography.bodySmall)
                                Text("엔진: ${if (nativeEngineAvailable) "연결됨" else "미연결"}", style = MaterialTheme.typography.bodySmall)
                                Text("최대 파일 크기: 64 MiB", style = MaterialTheme.typography.bodySmall)
                                Text("카탈로그: ${runCatching { JSONObject(catalogJson).optInt("count") }.getOrDefault(0)}개 도구",
                                    style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}
